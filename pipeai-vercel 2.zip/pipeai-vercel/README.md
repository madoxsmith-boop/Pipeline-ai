# Pipe AI — Vercel Deployment

## What's in this folder

```
pipeai-vercel/
├── package.json          ← tells Vercel it's a Next.js app
├── src/
│   └── app/
│       ├── layout.js     ← sets page title
│       ├── page.js       ← entry point
│       └── PipeAI.jsx    ← your entire app
```

## Deploy to Vercel (10 minutes)

### Step 1 — Create a GitHub account
Go to github.com and sign up (free)

### Step 2 — Create a new repository
1. Click the green "New" button
2. Name it: `pipe-ai`
3. Set to Private
4. Click "Create repository"

### Step 3 — Upload these files
1. Click "uploading an existing file"
2. Drag the entire `pipeai-vercel` folder contents
3. Click "Commit changes"

### Step 4 — Deploy on Vercel
1. Go to vercel.com
2. Click "Sign up" → "Continue with GitHub"
3. Click "New Project"
4. Select your `pipe-ai` repository
5. Click "Deploy" — done in 60 seconds

### Step 5 — Your live URL
Vercel gives you a URL like:
`https://pipe-ai-madox.vercel.app`

That's your live app. Share it with anyone.

## Custom domain (optional)
Buy `pipeai.com` on Namecheap (~$12/year)
Then in Vercel: Settings → Domains → Add domain

## Cost
- Vercel: FREE (Hobby plan handles your usage)
- GitHub: FREE
- Domain: $12/year (optional)
