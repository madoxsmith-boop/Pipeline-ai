export const metadata = {
  title: "Pipe AI — UA Local 38",
  description: "AI-powered piping blueprint generator for UA Local 38 San Francisco pipefitters.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0 }}>{children}</body>
    </html>
  );
}
