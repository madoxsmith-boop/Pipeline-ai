"use client";
import { useState, useRef, useEffect } from "react";

const SYS = {
  "Domestic Hot Water":   { m:"#c0392b", a:"DHW", t:"#fff", d:"125 PSI @ 210F", ret:true,  ins:true  },
  "Domestic Cold Water":  { m:"#1a6fa8", a:"CW",  t:"#fff", d:"125 PSI @ 60F",  ret:false, ins:false },
  "Steam":                { m:"#b7950b", a:"STM", t:"#000", d:"15 PSI @ 250F",  ret:true,  ins:true  },
  "Condensate Return":    { m:"#0e6655", a:"CR",  t:"#fff", d:"30 PSI @ 212F",  ret:false, ins:true  },
  "Chilled Water Supply": { m:"#154360", a:"CWS", t:"#fff", d:"125 PSI @ 45F",  ret:true,  ins:true  },
  "Chilled Water Return": { m:"#1a5276", a:"CWR", t:"#fff", d:"125 PSI @ 55F",  ret:false, ins:true  },
  "Hydronic Heating":     { m:"#943126", a:"HHW", t:"#fff", d:"125 PSI @ 180F", ret:true,  ins:true  },
  "Process Piping":       { m:"#6c3483", a:"PRO", t:"#fff", d:"VARIES",         ret:false, ins:false },
  "Gas (Med Pressure)":   { m:"#9a7d0a", a:"GAS", t:"#000", d:"5 PSI MAX",      ret:false, ins:false },
  "Fire Protection":      { m:"#c0392b", a:"FP",  t:"#fff", d:"175 PSI",        ret:false, ins:false },
};
const gs = s => SYS[s] || SYS["Domestic Hot Water"];

function buildJob(inp) {
  const ft = Math.max(parseFloat(inp.runLength) || 100, 10);
  const sz = parseFloat(inp.pipeSize) || 2;
  const hs = sz >= 6 ? 16 : sz >= 4 ? 14 : sz >= 2 ? 10 : 8;
  const nv = Math.max(2, Math.round(ft / 50));
  const isR = /floor|riser|vertical|rise|story/i.test(inp.jobDesc || "");
  const sc = gs(inp.systemType);
  const nFl = isR ? 3 : 0;
  const seg1 = isR ? ft * 0.36 : ft;
  const seg2 = isR ? ft * 0.22 : 0;
  const seg3 = isR ? ft * 0.42 : 0;
  const testPSI = Math.round((parseFloat(sc.d) || 125) * 1.5);
  const bh = sz <= 1 ? 0.18 : sz <= 2 ? 0.25 : sz <= 3 ? 0.32 : sz <= 4 ? 0.38 : 0.50;
  const jf = inp.joiningMethod.includes("Weld") ? 1.55 : inp.joiningMethod === "Grooved / Victaulic" ? 1.1 : 1.0;
  const bf = inp.buildingType === "Hospital / Healthcare" ? 1.3 : inp.buildingType === "Lab / R&D" ? 1.25 : 1.0;
  const sf = /oshpd/i.test(inp.special || "") ? 1.35 : /confined/i.test(inp.special || "") ? 1.2 : 1.0;
  const base = ft * bh * jf * bf * sf;
  const minH = Math.round(base * 0.85);
  const maxH = Math.round(base * 1.15);
  const pm = sc.ret ? 2.1 : 1.05;
  const mats = [
    { c:"PIPE",     i:`${inp.pipeSize} ${inp.material} Pipe`,            q:Math.round(ft*pm),              u:"LF" },
    { c:"FITTINGS", i:`${inp.pipeSize} 90 deg Elbow`,                    q:Math.round(ft/18),              u:"EA" },
    { c:"FITTINGS", i:`${inp.pipeSize} 45 deg Elbow`,                    q:Math.round(ft/45),              u:"EA" },
    { c:"FITTINGS", i:`${inp.pipeSize} Straight Tee`,                    q:Math.round(ft/35),              u:"EA" },
    { c:"FITTINGS", i:`${inp.pipeSize} Reducing Tee`,                    q:Math.max(1,Math.round(ft/70)),  u:"EA" },
    { c:"FITTINGS", i:`${inp.pipeSize} Concentric Reducer`,              q:Math.max(1,Math.round(ft/90)),  u:"EA" },
    { c:"FITTINGS", i:`${inp.pipeSize} Union`,                           q:Math.max(2,nv*2),               u:"EA" },
    { c:"VALVES",   i:`${inp.pipeSize} Gate Valve OS&Y`,                 q:nv,                             u:"EA" },
    { c:"VALVES",   i:`${inp.pipeSize} Globe Valve`,                     q:Math.max(1,Math.round(nv/2)),   u:"EA" },
    { c:"VALVES",   i:`${inp.pipeSize} Swing Check Valve`,               q:Math.max(1,Math.round(nv/3)),   u:"EA" },
    { c:"VALVES",   i:`${inp.pipeSize} Ball Valve Full Port`,            q:Math.max(1,Math.round(nv/3)),   u:"EA" },
    { c:"VALVES",   i:`${inp.pipeSize} Y-Strainer 1/16in Mesh`,         q:Math.max(1,Math.round(nv/2)),   u:"EA" },
    { c:"INST",     i:"Pressure Gauge 0-160 PSI 2.5in Dial w/ Siphon",  q:Math.max(2,Math.round(ft/80)),  u:"EA" },
    { c:"INST",     i:"Thermometer 9in Stem Adj Angle w/ Thermowell",   q:Math.max(2,Math.round(ft/70)),  u:"EA" },
    { c:"INST",     i:"Auto Air Vent 1/2in FPT Float Type",             q:isR?nFl:1,                      u:"EA" },
    { c:"INST",     i:"Drain Valve 3/4in Gate Hose End",                q:Math.max(1,Math.round(ft/70)),  u:"EA" },
    { c:"SUPPORTS", i:`${inp.pipeSize} Clevis Hanger ANVIL Fig.260`,    q:Math.round(ft/hs),              u:"EA" },
    { c:"SUPPORTS", i:"3/8in A307 All-Thread Rod x 10ft",               q:Math.round(ft/hs)*2,            u:"EA" },
    { c:"SUPPORTS", i:`${inp.pipeSize} Riser Clamp ANVIL Fig.261`,      q:isR?nFl*2:0,                    u:"EA" },
    { c:"MISC",     i:`${inp.pipeSize} Expansion Loop Shop Fab`,         q:Math.max(1,Math.round(ft/120)), u:"EA" },
    { c:"MISC",     i:"4x4 Galv Pipe Sleeve",                           q:isR?nFl:Math.round(ft/120),     u:"EA" },
    { c:"MISC",     i:"UL Firestop Sealant 3M CP-25WB+",               q:isR?nFl:0,                      u:"KT" },
  ];
  if (sc.ins) mats.push({ c:"INSUL", i:`${inp.pipeSize} Fiberglass Insulation 1in ASJ`, q:Math.round(ft*pm), u:"LF" });
  if (/seismic|oshpd/i.test(inp.special||"")) mats.push({ c:"SUPPORTS", i:"Seismic Brace Assy SMACNA", q:Math.round(ft/40), u:"EA" });
  if (inp.joiningMethod.includes("Weld")) mats.push({ c:"MISC", i:"Welding Rod E7018", q:Math.round(ft/10), u:"LB" });
  const dwgNo = "L-" + String(Math.floor((ft*7+sz*317)%900+100)).padStart(3,"0");
  const today = new Date().toLocaleDateString("en-US",{month:"2-digit",day:"2-digit",year:"numeric"});
  return {
    routing: isR
      ? `Vertical ${inp.pipeSize} ${inp.material} ${inp.systemType.toLowerCase()} riser through pipe chase. ${inp.joiningMethod} connections. ANVIL Fig.261 riser clamps at each floor with 2in clearance sleeve and UL firestop. Min. 3-elbow swing joints at branch takeoffs per ASHRAE 90.1. Auto air vent at top, 3/4in drain at low point. Coordinate slab penetrations with structural EOR before core drilling. Seismic bracing per CBC Chapter 16 and SMACNA IEMP 2nd Ed.`
      : `Horizontal ${inp.pipeSize} ${inp.material} pipe at EL.+${Math.round(8+sz*0.5)}ft-0in AFF. Slope ${sz>=2?"1/8":"1/4"}in per foot to low-point drains. Y-strainer at source. ANVIL Fig.260 clevis hangers at ${hs}ft-0in max o.c. on 3/8in A307 all-thread. Expansion loops at 100 LF max. OS&Y gate valves with unions each side. Pressure gauges at supply and return. Min 3in clearance to electrical, 6in to ductwork.`,
    compliance: `2022 CPC, OSHA 29 CFR 1926 Subpart P, CBC 2022 Ch.16, ASHRAE 90.1.${/oshpd/i.test(inp.special||"") ? " OSHPD/HCAI: Submit OSP and stamped drawings to AHJ before construction." : ""}\n\nInsulation: ${sc.ins ? "1in fiberglass with ASJ jacket per Title 24 Part 6. All fittings and valves insulated." : "Not required per Title 24 Part 6."}\n\nPressure test: Hydrostatic at ${testPSI} PSI (1.5x MAWP), 4-hour witnessed hold, inspector signs Form P-1.\n\nWelding: AWS D1.1/B31.9 certified welders required. Hangers: ANVIL or GRINNELL, engineer-stamped schedule required.`,
    laborNotes: `Mobilization and layout:  ${Math.round(minH*.08)}-${Math.round(maxH*.08)} hrs\nShop fabrication and joining:  ${Math.round(minH*.28)}-${Math.round(maxH*.28)} hrs\nHanger and support install:  ${Math.round(minH*.12)}-${Math.round(maxH*.12)} hrs\nPipe installation and alignment:  ${Math.round(minH*.20)}-${Math.round(maxH*.20)} hrs\nValves, instruments, specialties:  ${Math.round(minH*.14)}-${Math.round(maxH*.14)} hrs\nHydrostatic test and flush:  ${Math.round(minH*.08)}-${Math.round(maxH*.08)} hrs\nPunch list and closeout:  ${Math.round(minH*.04)}-${Math.round(maxH*.04)} hrs`,
    prefab: `Fabricate in ${Math.min(20,Math.round(ft/8))}-ft shop spools. Number, photograph, and tag each before shipping.\n\nPre-assemble valve stations (OS&Y valve + unions + gauge + thermometer + bracket) as drop-in cartridge assemblies.\n\n${inp.joiningMethod.includes("Weld") ? "AWS certified welder for all shop welds. 100% VT + 10% RT on pressure welds. Field welds at spool connections only." : inp.joiningMethod==="Grooved / Victaulic" ? "Power-groove all pipe ends per Victaulic spec. Field: coupling makeup and torque only." : "Power-thread all nipples to final length in shop. Bag and tag by zone."}\n\nTarget 70-75% prefab ratio. Reduces field labor 30-40%.`,
    mats, laborHours:`${minH}-${maxH}`, isR, hs, nv, sc, seg1, seg2, seg3, nFl, testPSI, dwgNo, today,
  };
}


// ═══════════════════════════════════════════════
// DRAWING ENGINE — ME STANDARD
// Line weights per ASME Y14.2:
//   Object/visible: 0.6mm (thick)
//   Hidden:         0.3mm
//   Dimension:      0.3mm
//   Centerline:     0.3mm
//   Text:           0.25mm min
// Canvas px approximation at 150dpi: 1mm ≈ 5.9px
// ═══════════════════════════════════════════════

const LW = {
THICK:   2.5,
MEDIUM:  1.5,
THIN:    0.8,
PHANTOM: 0.5,
ULTRA:   0.3,
};
function initCanvas(ctx, W, H) {
ctx.fillStyle = "#ffffff";
ctx.fillRect(0, 0, W, H);
ctx.fillStyle = "rgba(252,250,245,0.6)";
ctx.fillRect(0, 0, W, H);
// VERSION STAMP — confirms new code is running
ctx.fillStyle = "#c8860a";
ctx.fillRect(30, 30, W-60, 4);
ctx.fillRect(30, H-34, W-60, 4);
ctx.strokeStyle = "#000"; ctx.lineWidth = 4;
ctx.strokeRect(6, 6, W-12, H-12);
ctx.lineWidth = 1.2;
ctx.strokeRect(30, 30, W-60, H-60);
ctx.fillStyle = "#f0f0f0";
ctx.fillRect(6, 6, 24, H-12);
ctx.fillRect(W-30, 6, 24, H-12);
ctx.fillRect(6, 6, W-12, 24);
ctx.fillRect(6, H-30, W-12, 24);
ctx.strokeStyle = "#999"; ctx.lineWidth = 0.4;
const zw = (W-60)/6, zh = (H-60)/6;
for (let i=1; i<6; i++) {
ctx.beginPath(); ctx.moveTo(30+i*zw, 6); ctx.lineTo(30+i*zw, 30); ctx.stroke();
ctx.beginPath(); ctx.moveTo(30+i*zw, H-30); ctx.lineTo(30+i*zw, H-6); ctx.stroke();
ctx.beginPath(); ctx.moveTo(6, 30+i*zh); ctx.lineTo(30, 30+i*zh); ctx.stroke();
ctx.beginPath(); ctx.moveTo(W-30, 30+i*zh); ctx.lineTo(W-6, 30+i*zh); ctx.stroke();
}
ctx.fillStyle = "#333";
ctx.font = "bold 8px Arial,sans-serif";
ctx.textAlign = "center";
"ABCDEF".split("").forEach((l,i) => {
const x = 30+i*zw+zw/2;
ctx.fillText(l, x, 21);
ctx.fillText(l, x, H-8);
});
for (let i=0; i<6; i++) {
const y = 30+i*zh+zh/2;
ctx.fillText(String(i+1), 18, y+4);
ctx.fillText(String(i+1), W-18, y+4);
}
ctx.strokeStyle = "rgba(0,0,200,0.04)"; ctx.lineWidth = 0.3;
for (let x=30; x<=W-30; x+=15) {
ctx.beginPath(); ctx.moveTo(x, 30); ctx.lineTo(x, H-30); ctx.stroke();
}
for (let y=30; y<=H-30; y+=15) {
ctx.beginPath(); ctx.moveTo(30, y); ctx.lineTo(W-30, y); ctx.stroke();
}
ctx.strokeStyle = "rgba(0,0,200,0.09)"; ctx.lineWidth = 0.4;
for (let x=30; x<=W-30; x+=75) {
ctx.beginPath(); ctx.moveTo(x, 30); ctx.lineTo(x, H-30); ctx.stroke();
}
for (let y=30; y<=H-30; y+=75) {
ctx.beginPath(); ctx.moveTo(30, y); ctx.lineTo(W-30, y); ctx.stroke();
}
}
function titleBlock(ctx, W, H, inp, job, view, sheet) {
const bh = 82, by = H-bh-6, cw = W-60;
ctx.fillStyle = "#faf8f2";
ctx.fillRect(30, by, cw, bh);
ctx.strokeStyle = "#000"; ctx.lineWidth = 2;
ctx.strokeRect(30, by, cw, bh);
ctx.lineWidth = 1;
ctx.beginPath(); ctx.moveTo(30, by+bh*0.5); ctx.lineTo(30+cw, by+bh*0.5); ctx.stroke();
const cols = [0.24, 0.47, 0.63, 0.79];
cols.forEach(c => {
ctx.beginPath(); ctx.moveTo(30+c*cw, by); ctx.lineTo(30+c*cw, by+bh); ctx.stroke();
});
const TX = (t, x, y, fs, col, bold, maxW) => {
ctx.fillStyle = col || "#000";
ctx.font = (bold ? "bold " : "") + fs + "px Arial,sans-serif";
ctx.textAlign = "left";
if (maxW) {
let s = String(t);
while (s.length > 2 && ctx.measureText(s).width > maxW) s = s.slice(0,-1);
if (s !== String(t)) s = s.slice(0,-2) + "..";
ctx.fillText(s, x, y);
} else {
ctx.fillText(String(t), x, y);
}
};
const p = 6, sc = job.sc;
const mw = (f) => cw*(cols[f]-(f>0?cols[f-1]:0))-p*2;
const c0=30+p, c1=30+cols[0]*cw+p, c2=30+cols[1]*cw+p, c3=30+cols[2]*cw+p, c4=30+cols[3]*cw+p;
const r1=by+12, r2=by+26, r3=by+38, r4=by+bh*0.5+14, r5=by+bh*0.5+27;
TX("PROJECT", c0,r1, 6.5,"#666");
TX("UA LOCAL 38 — PIPE AI", c0,r2, 10,"#000",true, mw(0));
TX(inp.buildingType.toUpperCase(), c0,r3, 8,"#000",false, mw(0));
TX("SAN FRANCISCO, CA", c0,r4, 8.5,"#000",false, mw(0));
TX("SFDBI | UA LOCAL 38 | UA DISTRICT 16", c0,r5, 7,"#666",false, mw(0));
TX("SYSTEM / SPEC", c1,r1, 6.5,"#666");
ctx.fillStyle = sc.m; ctx.font = "bold 9.5px Arial,sans-serif"; ctx.textAlign = "left";
let sys = inp.systemType.toUpperCase(); while(sys.length>2 && ctx.measureText(sys).width>mw(1)) sys=sys.slice(0,-1); if(sys!==inp.systemType.toUpperCase()) sys=sys.slice(0,-2)+"..";
ctx.fillText(sys, c1, r2);
TX(inp.pipeSize+" "+inp.material.substring(0,18).toUpperCase(), c1,r3, 7.5,"#000",false,mw(1));
TX(inp.joiningMethod.toUpperCase(), c1,r4, 8,"#000",false,mw(1));
TX("["+sc.a+"]  "+inp.runLength+" LF  |  "+sc.d, c1,r5, 7,"#666",false,mw(1));
TX("DRAWING TYPE", c2,r1, 6.5,"#666");
TX(view, c2,r2, 8.5,"#c8860a",true,mw(2));
TX("SYMBOLS: ASME Y32.2.3", c2,r3, 7,"#666",false,mw(2));
ctx.fillStyle="#c0392b"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText("NOT FOR CONSTRUCTION", c2,r4);
TX("VERIFY DIMS IN FIELD", c2,r5, 7,"#888",false,mw(2));
TX("DATE", c3,r1, 6.5,"#666");
TX(job.today, c3,r2, 9,"#000",true);
TX("DRAWN:  PIPE AI v8.0", c3,r3, 7,"#666");
TX("CHECKED:  ___________", c3,r4, 7,"#999");
TX("APPROVED: ___________", c3,r5, 7,"#999");
TX("DWG NO.", c4,r1, 6.5,"#666");
ctx.fillStyle="#000"; ctx.font="bold 16px 'Courier New',monospace"; ctx.textAlign="left";
ctx.fillText(job.dwgNo, c4, r2+3);
TX("REV: A", c4,r3, 9,"#000",true);
TX("SHEET "+sheet+" OF 3", c4,r4, 9,"#000",true);
TX("TEST: "+job.testPSI+" PSI HYD.", c4,r5, 7.5,"#666");
}
function dim(ctx, x1, y1, x2, y2, lbl, side, col) {
side = side||1; col = col||"#000";
const dx=x2-x1, dy=y2-y1, len=Math.sqrt(dx*dx+dy*dy);
if (len < 4) return;
const nx=-dy/len, ny=dx/len, off=side*36;
ctx.strokeStyle=col; ctx.lineWidth=LW.THIN; ctx.setLineDash([]);
ctx.beginPath(); ctx.moveTo(x1+nx*4,y1+ny*4); ctx.lineTo(x1+nx*off,y1+ny*off); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x2+nx*4,y2+ny*4); ctx.lineTo(x2+nx*off,y2+ny*off); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x1+nx*off,y1+ny*off); ctx.lineTo(x2+nx*off,y2+ny*off); ctx.stroke();
const aL=9, aW=3;
[[x1,y1,1],[x2,y2,-1]].forEach(([px,py,d]) => {
const ax=dx/len*d, ay=dy/len*d;
ctx.fillStyle=col;
ctx.beginPath();
ctx.moveTo(px+nx*off, py+ny*off);
ctx.lineTo(px+nx*off+ax*aL-ny*aW, py+ny*off+ay*aL+nx*aW);
ctx.lineTo(px+nx*off+ax*aL+ny*aW, py+ny*off+ay*aL-nx*aW);
ctx.closePath(); ctx.fill();
});
const mx=(x1+x2)/2+nx*off, my=(y1+y2)/2+ny*off+(side>0?-7:16);
ctx.font = "bold 8.5px Arial,sans-serif";
const tw = ctx.measureText(lbl).width+10;
ctx.fillStyle="#fff"; ctx.fillRect(mx-tw/2,my-11,tw,14);
ctx.fillStyle=col; ctx.textAlign="center"; ctx.fillText(lbl,mx,my);
}
function leader(ctx, x1, y1, x2, y2, text, col, alignRight) {
col = col||"#000"; alignRight = alignRight!==false;
ctx.strokeStyle=col; ctx.lineWidth=LW.THIN;
ctx.fillStyle=col; ctx.beginPath(); ctx.arc(x1,y1,2.5,0,Math.PI*2); ctx.fill();
ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
const tail = alignRight ? 34 : -34;
ctx.beginPath(); ctx.moveTo(x2,y2); ctx.lineTo(x2+tail,y2); ctx.stroke();
ctx.font="7.5px Arial,sans-serif"; ctx.textAlign=alignRight?"left":"right";
ctx.fillStyle=col;
ctx.fillText(text, x2+tail+(alignRight?3:-3), y2+3);
}
function northArrow(ctx, x, y) {
ctx.strokeStyle="#000"; ctx.lineWidth=1.5;
ctx.beginPath(); ctx.arc(x,y,20,0,Math.PI*2); ctx.stroke();
ctx.fillStyle="#000";
ctx.beginPath(); ctx.moveTo(x,y-18); ctx.lineTo(x+7,y+9); ctx.lineTo(x,y+5); ctx.closePath(); ctx.fill();
ctx.fillStyle="#fff";
ctx.beginPath(); ctx.moveTo(x,y-18); ctx.lineTo(x-7,y+9); ctx.lineTo(x,y+5); ctx.closePath(); ctx.fill();
ctx.strokeStyle="#000"; ctx.lineWidth=0.8; ctx.stroke();
ctx.lineWidth=0.5;
ctx.beginPath(); ctx.moveTo(x-20,y); ctx.lineTo(x+20,y); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x,y-20); ctx.lineTo(x,y+20); ctx.stroke();
ctx.fillStyle="#000"; ctx.font="bold 11px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("N", x, y-22);
}
function tagBox(ctx, x, y, tag) {
if (!tag) return;
ctx.font = "bold 7.5px Arial,sans-serif";
const tw = ctx.measureText(tag).width+10;
ctx.fillStyle="#fffce0"; ctx.strokeStyle="#000"; ctx.lineWidth=0.8;
ctx.fillRect(x-tw/2, y, tw, 13);
ctx.strokeRect(x-tw/2, y, tw, 13);
ctx.fillStyle="#000"; ctx.textAlign="center";
ctx.fillText(tag, x, y+9.5);
}
function symGate(ctx, x, y, S, tag) {
ctx.fillStyle="#000"; ctx.strokeStyle="#000"; ctx.lineWidth=LW.THICK;
ctx.beginPath(); ctx.moveTo(x-S,y-S); ctx.lineTo(x-S,y+S); ctx.lineTo(x,y); ctx.closePath(); ctx.fill();
ctx.beginPath(); ctx.moveTo(x+S,y-S); ctx.lineTo(x+S,y+S); ctx.lineTo(x,y); ctx.closePath(); ctx.fill();
ctx.fillStyle="#444"; ctx.lineWidth=1;
ctx.fillRect(x-4,y-S-11,8,12); ctx.strokeRect(x-4,y-S-11,8,12);
ctx.lineWidth=1.5; ctx.strokeStyle="#000";
ctx.beginPath(); ctx.moveTo(x,y-S-11); ctx.lineTo(x,y-S-24); ctx.stroke();
ctx.lineWidth=1.5;
ctx.beginPath(); ctx.arc(x,y-S-31,11,0,Math.PI*2); ctx.stroke();
ctx.lineWidth=1;
[[0,11],[11,0],[0,-11],[-11,0]].forEach(([dx,dy])=>{
ctx.beginPath();ctx.moveTo(x,y-S-31);ctx.lineTo(x+dx,y-S-31+dy);ctx.stroke();
});
ctx.lineWidth=1.5;
ctx.beginPath();ctx.moveTo(x-11,y-S-42);ctx.lineTo(x+11,y-S-42);ctx.stroke();
tagBox(ctx, x, y+S+5, tag);
}
function symGlobe(ctx, x, y, S, tag) {
ctx.fillStyle="#000"; ctx.strokeStyle="#000"; ctx.lineWidth=LW.THICK;
ctx.beginPath(); ctx.moveTo(x-S,y-S); ctx.lineTo(x-S,y+S); ctx.lineTo(x,y); ctx.closePath(); ctx.fill();
ctx.beginPath(); ctx.moveTo(x+S,y-S); ctx.lineTo(x+S,y+S); ctx.lineTo(x,y); ctx.closePath(); ctx.fill();
ctx.fillStyle="#fff"; ctx.lineWidth=1.2;
ctx.beginPath(); ctx.arc(x,y,S*0.52,0,Math.PI*2); ctx.fill(); ctx.stroke();
ctx.fillStyle="#444"; ctx.lineWidth=1;
ctx.fillRect(x-4,y-S-11,8,12); ctx.strokeRect(x-4,y-S-11,8,12);
ctx.lineWidth=1.5; ctx.strokeStyle="#000";
ctx.beginPath(); ctx.moveTo(x,y-S-11); ctx.lineTo(x,y-S-23); ctx.stroke();
ctx.beginPath(); ctx.arc(x,y-S-30,9,0,Math.PI*2); ctx.stroke();
ctx.lineWidth=1;
ctx.beginPath();ctx.moveTo(x-9,y-S-30);ctx.lineTo(x+9,y-S-30);ctx.stroke();
tagBox(ctx, x, y+S+5, tag);
}
function symCheck(ctx, x, y, S, tag) {
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=LW.THICK;
ctx.beginPath(); ctx.moveTo(x-S,y-S); ctx.lineTo(x-S,y+S); ctx.lineTo(x,y); ctx.closePath();
ctx.fill(); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x,y-S); ctx.lineTo(x,y+S); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(x+S,y); ctx.stroke();
ctx.fillStyle="#000";
ctx.beginPath(); ctx.arc(x,y-S,3,0,Math.PI*2); ctx.fill();
tagBox(ctx, x, y+S+5, tag);
}
function symBall(ctx, x, y, S, tag) {
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=LW.THICK;
ctx.fillRect(x-S,y-S,S*2,S*2); ctx.strokeRect(x-S,y-S,S*2,S*2);
ctx.lineWidth=1.2;
ctx.beginPath(); ctx.arc(x,y,S*0.52,0,Math.PI*2); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x-S*0.52,y); ctx.lineTo(x+S*0.52,y); ctx.stroke();
ctx.lineWidth=2;
ctx.beginPath(); ctx.moveTo(x,y-S); ctx.lineTo(x,y-S-16); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x-9,y-S-16); ctx.lineTo(x+9,y-S-16); ctx.stroke();
tagBox(ctx, x, y+S+5, tag);
}
function symButterfly(ctx, x, y, S, tag) {
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=LW.THICK;
ctx.beginPath(); ctx.arc(x,y,S,0,Math.PI*2); ctx.fill(); ctx.stroke();
ctx.lineWidth=1.2;
ctx.beginPath(); ctx.moveTo(x-S,y); ctx.bezierCurveTo(x-S/2,y-S*0.75,x+S/2,y-S*0.75,x+S,y); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x-S,y); ctx.bezierCurveTo(x-S/2,y+S*0.75,x+S/2,y+S*0.75,x+S,y); ctx.stroke();
ctx.lineWidth=1.5;
ctx.beginPath(); ctx.moveTo(x,y-S); ctx.lineTo(x,y-S-14); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x-8,y-S-14); ctx.lineTo(x+8,y-S-14); ctx.stroke();
tagBox(ctx, x, y+S+5, tag);
}
function symStrainer(ctx, x, y, S, tag) {
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=LW.THICK;
ctx.beginPath();
ctx.moveTo(x-S,y); ctx.lineTo(x,y-S); ctx.lineTo(x+S,y); ctx.lineTo(x,y+S);
ctx.closePath(); ctx.fill(); ctx.stroke();
ctx.lineWidth=1.2;
ctx.beginPath(); ctx.moveTo(x,y-S*0.48); ctx.lineTo(x,y+S*0.4); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x-S*0.48,y+S*0.1); ctx.lineTo(x,y+S*0.4); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x+S*0.48,y+S*0.1); ctx.lineTo(x,y+S*0.4); ctx.stroke();
ctx.lineWidth=0.5;
for (let i=-2;i<=2;i++) {
ctx.beginPath();ctx.moveTo(x+i*S*0.2,y-S*0.28);ctx.lineTo(x+i*S*0.2,y+S*0.32);ctx.stroke();
}
tagBox(ctx, x, y+S+5, tag);
}
function symGauge(ctx, x, y, tag) {
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=1.5;
ctx.beginPath(); ctx.arc(x,y,12,0,Math.PI*2); ctx.fill(); ctx.stroke();
ctx.lineWidth=0.8;
for (let a=0; a<5; a++) {
const ang = -Math.PI*0.8 + a*Math.PI*0.4;
ctx.beginPath();
ctx.moveTo(x+Math.cos(ang)*8, y+Math.sin(ang)*8);
ctx.lineTo(x+Math.cos(ang)*12, y+Math.sin(ang)*12);
ctx.stroke();
}
ctx.lineWidth=1; ctx.strokeStyle="#000";
ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(x-4,y-8); ctx.stroke();
ctx.fillStyle="#000"; ctx.font="bold 7px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("P",x+4,y+4);
ctx.lineWidth=1.2;
ctx.beginPath(); ctx.moveTo(x,y+12); ctx.lineTo(x,y+18); ctx.stroke();
ctx.beginPath(); ctx.arc(x+4,y+22,4,Math.PI,0); ctx.stroke();
if (tag) {
ctx.fillStyle="#555"; ctx.font="7px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText(tag,x,y+33);
}
}
function symThermo(ctx, x, y, tag) {
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=1.5;
ctx.fillRect(x-6,y-12,12,24); ctx.strokeRect(x-6,y-12,12,24);
ctx.fillStyle="#c0392b"; ctx.lineWidth=1;
ctx.beginPath(); ctx.arc(x,y+14,5.5,0,Math.PI*2); ctx.fill(); ctx.stroke();
ctx.fillStyle="#c0392b";
ctx.fillRect(x-2,y-8,4,22);
ctx.strokeStyle="#000"; ctx.lineWidth=0.6;
for (let i=0;i<5;i++) {
ctx.beginPath();ctx.moveTo(x+2,y-9+i*6);ctx.lineTo(x+6,y-9+i*6);ctx.stroke();
}
ctx.lineWidth=1.5; ctx.strokeStyle="#000";
ctx.beginPath(); ctx.moveTo(x,y+20); ctx.lineTo(x,y+28); ctx.stroke();
if (tag) {
ctx.fillStyle="#555"; ctx.font="7px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText(tag,x,y+38);
}
}
function symAV(ctx, x, y) {
ctx.fillStyle="#000"; ctx.strokeStyle="#000"; ctx.lineWidth=1.5;
ctx.beginPath(); ctx.moveTo(x,y-13); ctx.lineTo(x-8,y+4); ctx.lineTo(x+8,y+4); ctx.closePath(); ctx.fill();
ctx.beginPath(); ctx.arc(x,y-17,4,0,Math.PI*2); ctx.fill();
ctx.lineWidth=1;
ctx.beginPath(); ctx.moveTo(x,y+4); ctx.lineTo(x,y+14); ctx.stroke();
ctx.fillStyle="#333"; ctx.font="7px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("A/V",x,y+24);
}
function symDrain(ctx, x, y) {
ctx.fillStyle="#000"; ctx.strokeStyle="#000"; ctx.lineWidth=1.5;
ctx.beginPath(); ctx.moveTo(x-7,y); ctx.lineTo(x+7,y); ctx.lineTo(x,y+13); ctx.closePath(); ctx.fill();
ctx.lineWidth=1;
ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(x,y-15); ctx.stroke();
ctx.fillStyle="#333"; ctx.font="7px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("D/V",x,y+24);
}
function symExpLoop(ctx, x, y, pR) {
const lh=54, lw=45;
ctx.strokeStyle="#000"; ctx.lineWidth=pR*2; ctx.lineCap="round";
ctx.beginPath();
ctx.moveTo(x,y);
ctx.lineTo(x,y-lh);
ctx.lineTo(x-lw,y-lh);
ctx.lineTo(x-lw,y+lh);
ctx.lineTo(x+lw,y+lh);
ctx.lineTo(x+lw,y-lh);
ctx.lineTo(x,y-lh);
ctx.lineTo(x,y);
ctx.stroke();
ctx.lineCap="butt";
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=0.8;
ctx.fillRect(x-30,y-lh-20,60,13); ctx.strokeRect(x-30,y-lh-20,60,13);
ctx.fillStyle="#000"; ctx.font="bold 7.5px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("EXP. LOOP",x,y-lh-11);
}
function symReducer(ctx, x, y, pR) {
const rL=pR+5, rS=Math.max(3,pR*0.5);
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=1.5;
ctx.beginPath();
ctx.moveTo(x-13,y-rL); ctx.lineTo(x+13,y-rS);
ctx.lineTo(x+13,y+rS); ctx.lineTo(x-13,y+rL);
ctx.closePath(); ctx.fill(); ctx.stroke();
}
function symFlange(ctx, x, y, pR, dir) {
ctx.strokeStyle="#000"; ctx.lineWidth=2.8;
ctx.beginPath(); ctx.moveTo(x,y-pR-5); ctx.lineTo(x,y+pR+5); ctx.stroke();
ctx.beginPath(); ctx.moveTo(x+dir*7,y-pR-5); ctx.lineTo(x+dir*7,y+pR+5); ctx.stroke();
ctx.fillStyle="#000";
[y-pR, y, y+pR].forEach(by => {
ctx.beginPath(); ctx.arc(x+dir*7,by,2,0,Math.PI*2); ctx.fill();
});
ctx.lineWidth=1;
ctx.beginPath();ctx.moveTo(x+dir*12,y-pR-2);ctx.lineTo(x+dir*12,y+pR+2);ctx.stroke();
}
function symHanger(ctx, hx, strY, pipeY, pR) {
ctx.strokeStyle="#555"; ctx.lineWidth=1; ctx.setLineDash([3,2]);
ctx.beginPath(); ctx.moveTo(hx,strY); ctx.lineTo(hx,pipeY-pR-2); ctx.stroke();
ctx.setLineDash([]);
ctx.strokeStyle="#333"; ctx.lineWidth=2;
ctx.beginPath(); ctx.moveTo(hx-14,pipeY-pR-20); ctx.lineTo(hx+14,pipeY-pR-20); ctx.stroke();
ctx.beginPath(); ctx.moveTo(hx-14,pipeY-pR-20); ctx.lineTo(hx-14,pipeY-pR-8); ctx.stroke();
ctx.beginPath(); ctx.moveTo(hx+14,pipeY-pR-20); ctx.lineTo(hx+14,pipeY-pR-8); ctx.stroke();
ctx.fillStyle="#333";
ctx.beginPath(); ctx.arc(hx,strY,3,0,Math.PI*2); ctx.fill();
}
function renderPlan(canvas, job, inp) {
const ctx = canvas.getContext("2d");
const W = canvas.width, H = canvas.height;
initCanvas(ctx,W,H);
const ft  = Math.max(parseFloat(inp.runLength)||100,10);
const sz  = parseFloat(inp.pipeSize)||2;
const pR  = Math.min(10,Math.max(4,sz*1.75));
const sc  = job.sc;
const L=50,R=W-50,T=55,B=H-110;
const supY = T+(B-T)*(sc.ret?0.33:0.50);
const retY = T+(B-T)*0.67;
const strY = supY - pR - 100;
const mg   = L+130;
const endX = R-130;
const pxPerFt = (endX-mg)/ft;
const S   = Math.max(13,pR*2.0);
const minGap = Math.max(100,ft*pxPerFt/12);
ctx.fillStyle="rgba(80,90,110,0.06)";
for(let bx=mg;bx<endX;bx+=70) {
ctx.fillRect(bx,strY-28,62,28);
ctx.strokeStyle="rgba(60,70,90,0.18)"; ctx.lineWidth=0.6;
for(let hx=bx+6;hx<bx+60;hx+=9){ctx.beginPath();ctx.moveTo(hx,strY-28);ctx.lineTo(hx+7,strY);ctx.stroke();}
}
ctx.strokeStyle="rgba(40,50,80,0.55)"; ctx.lineWidth=3; ctx.setLineDash([]);
ctx.beginPath(); ctx.moveTo(mg-50,strY); ctx.lineTo(endX+50,strY); ctx.stroke();
ctx.fillStyle="rgba(40,50,80,0.6)"; ctx.font="8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("STRUCTURAL STEEL FRAMING — SEE STRUCTURAL DRAWINGS",(mg+endX)/2,strY-8);
const drawPipe = (py, colorMain, label, flowRight) => {
if (sc.ins) {
const iW = pR*2.0;
ctx.fillStyle=`rgba(200,160,40,0.06)`;
ctx.fillRect(mg,py-iW/2,endX-mg,iW);
ctx.strokeStyle="rgba(160,110,30,0.5)"; ctx.lineWidth=0.8; ctx.setLineDash([6,4]);
ctx.beginPath();ctx.moveTo(mg,py-iW/2);ctx.lineTo(endX,py-iW/2);ctx.stroke();
ctx.beginPath();ctx.moveTo(mg,py+iW/2);ctx.lineTo(endX,py+iW/2);ctx.stroke();
ctx.setLineDash([]);
const lix=mg+ft*pxPerFt*0.18;
leader(ctx,lix,py-iW/2,lix-20,py-iW/2-28,"INSUL. 1\" FBG/ASJ (TYP.)","#666",false);
}
for(let f=job.hs;f<ft-4;f+=job.hs) {
symHanger(ctx,mg+f*pxPerFt,strY,py,pR);
}
ctx.strokeStyle="#000"; ctx.lineWidth=pR*2; ctx.lineCap="butt";
ctx.beginPath(); ctx.moveTo(mg,py); ctx.lineTo(endX,py); ctx.stroke();
const bw = Math.min(64,ft*pxPerFt*0.10);
const bx = mg+ft*pxPerFt*0.36;
ctx.fillStyle=colorMain; ctx.fillRect(bx,py-pR,bw,pR*2);
ctx.strokeStyle="#000"; ctx.lineWidth=0.6; ctx.strokeRect(bx,py-pR,bw,pR*2);
ctx.fillStyle=sc.t; ctx.font=`bold ${Math.max(9,pR*1.05)}px Arial,sans-serif`;
ctx.textAlign="center"; ctx.fillText(sc.a,bx+bw/2,py+pR*0.38);
ctx.strokeStyle="#000"; ctx.lineWidth=LW.PHANTOM; ctx.setLineDash([16,4,4,4]);
ctx.beginPath(); ctx.moveTo(mg-60,py); ctx.lineTo(endX+60,py); ctx.stroke();
ctx.setLineDash([]);
ctx.fillStyle="#000"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText("CL",mg-58,py-3);
ctx.fillStyle=colorMain; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText(label, mg, py-pR-30);
const midX=(mg+endX)/2;
ctx.fillStyle="#fff"; ctx.fillRect(midX-40,py-8,80,17);
ctx.strokeStyle="#000"; ctx.lineWidth=0.6; ctx.strokeRect(midX-40,py-8,80,17);
ctx.fillStyle="#000"; ctx.font="bold 8px 'Courier New',monospace"; ctx.textAlign="center";
ctx.fillText(inp.pipeSize+" "+inp.material.substring(0,14),midX,py+4);
const arStep=ft*pxPerFt/4;
const arDir = flowRight ? 1 : -1;
const arStart = flowRight ? mg+arStep*0.6 : endX-arStep*0.6;
ctx.fillStyle="rgba(0,0,0,0.7)";
const ax=arStart;
if(flowRight){
ctx.beginPath();ctx.moveTo(ax+13,py);ctx.lineTo(ax-1,py-6);ctx.lineTo(ax+2,py);ctx.lineTo(ax-1,py+6);ctx.closePath();ctx.fill();
ctx.fillStyle="#000";ctx.font="7px Arial,sans-serif";ctx.textAlign="left";ctx.fillText("FLOW",ax+16,py+3);
} else {
ctx.beginPath();ctx.moveTo(ax-13,py);ctx.lineTo(ax+1,py-6);ctx.lineTo(ax-2,py);ctx.lineTo(ax+1,py+6);ctx.closePath();ctx.fill();
ctx.fillStyle="#000";ctx.font="7px Arial,sans-serif";ctx.textAlign="right";ctx.fillText("FLOW",ax-16,py+3);
}
};
drawPipe(supY, sc.m, "SUPPLY — "+inp.pipeSize+" "+inp.material+" ["+sc.a+"]  "+sc.d, true);
let lastX = -9999;
const supSyms = [
[0.04, x=>symStrainer(ctx,x,supY,S,"STR-1")],
[0.11, x=>symGauge(ctx,x,supY-pR-30,"PG-1")],
[0.17, x=>symThermo(ctx,x,supY-pR-26,"TI-1")],
[0.24, x=>symCheck(ctx,x,supY,S,"CV-1")],
[0.32, x=>{ ctx.fillStyle="#000";ctx.beginPath();ctx.arc(x,supY,pR*0.85,0,Math.PI*2);ctx.fill(); }],
[0.40, x=>symGate(ctx,x,supY,S,"GV-1")],
[0.50, x=>symExpLoop(ctx,x,supY,pR)],
[0.59, x=>symBall(ctx,x,supY,S,"BV-1")],
[0.67, x=>symButterfly(ctx,x,supY,S,"BFV-1")],
[0.75, x=>symGlobe(ctx,x,supY,S,"GLV-1")],
[0.82, x=>symReducer(ctx,x,supY,pR)],
[0.88, x=>symGauge(ctx,x,supY-pR-30,"PG-2")],
[0.93, x=>symThermo(ctx,x,supY-pR-26,"TI-2")],
[0.97, x=>symAV(ctx,x,supY-pR-10)],
];
supSyms.forEach(([f,fn]) => {
const sx = mg+f*ft*pxPerFt;
if (sx>mg+20 && sx<endX-20 && sx-lastX>=minGap) { fn(sx); lastX=sx; }
});
symDrain(ctx,endX-22,supY+pR+8);
symFlange(ctx,mg,supY,pR,1);
ctx.fillStyle="#1a3060"; ctx.strokeStyle="#2471a3"; ctx.lineWidth=1.5;
ctx.fillRect(mg-96,supY-18,90,36); ctx.strokeRect(mg-96,supY-18,90,36);
ctx.fillStyle="#74b9ff"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("SUPPLY",mg-51,supY-3); ctx.fillText("SOURCE",mg-51,supY+10);
symFlange(ctx,endX,supY,pR,-1);
ctx.fillStyle="#601a1a"; ctx.strokeStyle="#c0392b"; ctx.lineWidth=1.5;
ctx.fillRect(endX+6,supY-18,90,36); ctx.strokeRect(endX+6,supY-18,90,36);
ctx.fillStyle="#fab1a0"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("SUPPLY",endX+51,supY-3); ctx.fillText("DEST.",endX+51,supY+10);
if (sc.ret) {
drawPipe(retY, sc.m, "RETURN — "+inp.pipeSize+" "+inp.material+" ["+sc.a+"]", false);
let lastRx=-9999;
const retSyms = [
[0.07, x=>symGate(ctx,x,retY,S,"GV-3")],
[0.28, x=>symStrainer(ctx,x,retY,S,"STR-2")],
[0.50, x=>symCheck(ctx,x,retY,S,"CV-2")],
[0.72, x=>symGate(ctx,x,retY,S,"GV-4")],
[0.87, x=>symGauge(ctx,x,retY-pR-30,"PG-3")],
[0.93, x=>symThermo(ctx,x,retY-pR-26,"TI-3")],
];
retSyms.forEach(([f,fn]) => {
const rx=mg+f*ft*pxPerFt;
if(rx>mg+20&&rx<endX-20&&rx-lastRx>=minGap){fn(rx);lastRx=rx;}
});
symDrain(ctx,endX-22,retY+pR+8);
symFlange(ctx,mg,retY,pR,1);
ctx.fillStyle="#1a3060"; ctx.strokeStyle="#2471a3"; ctx.lineWidth=1.5;
ctx.fillRect(mg-96,retY-18,90,36); ctx.strokeRect(mg-96,retY-18,90,36);
ctx.fillStyle="#74b9ff"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("RETURN",mg-51,retY-3); ctx.fillText("DEST.",mg-51,retY+10);
symFlange(ctx,endX,retY,pR,-1);
ctx.fillStyle="#601a1a"; ctx.strokeStyle="#c0392b"; ctx.lineWidth=1.5;
ctx.fillRect(endX+6,retY-18,90,36); ctx.strokeRect(endX+6,retY-18,90,36);
ctx.fillStyle="#fab1a0"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("RETURN",endX+51,retY-3); ctx.fillText("SOURCE",endX+51,retY+10);
dim(ctx,endX+80,supY,endX+80,retY,
Math.round((retY-supY)/pxPerFt*0.5+8)+"\"",
1,"#555");
}
dim(ctx,mg,supY+pR+14,endX,supY+pR+14,ft+"'-0\"  TOTAL RUN",-1,"#000");
if(ft>20&&pxPerFt>3){
const hx1=mg+job.hs*pxPerFt,hx2=mg+job.hs*2*pxPerFt;
if(hx2<endX-60) dim(ctx,hx1,supY-pR-14,hx2,supY-pR-14,job.hs+"'-0\" TYP.",1,"#555");
}
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(mg-120,supY-16,88,32); ctx.strokeRect(mg-120,supY-16,88,32);
ctx.fillStyle="#000"; ctx.font="bold 7.5px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("EL. +"+Math.round(8+sz*0.5)+"'-0\" AFF",mg-76,supY-2);
ctx.font="7px Arial,sans-serif"; ctx.fillText("SLOPE: "+( sz>=2?"1/8":"1/4" )+"\" / FT",mg-76,supY+11);
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(mg,T+40,268,80); ctx.strokeRect(mg,T+40,268,80);
ctx.fillStyle="#c8860a"; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText("PIPE SPECIFICATION",mg+8,T+55);
ctx.strokeStyle="#000"; ctx.lineWidth=0.5;
ctx.beginPath();ctx.moveTo(mg,T+59);ctx.lineTo(mg+268,T+59);ctx.stroke();
ctx.fillStyle="#000"; ctx.font="8px Arial,sans-serif";
[
"SIZE:    "+inp.pipeSize,
"MATERIAL: "+inp.material,
"SERVICE:  "+inp.systemType.substring(0,26),
"JOINING:  "+inp.joiningMethod,
"DESIGN:   "+sc.d,
"TEST:     "+job.testPSI+" PSI HYDROSTATIC",
].forEach((t,i)=>ctx.fillText(t,mg+8,T+71+i*11.5));
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(L+36,B-158,430,148); ctx.strokeRect(L+36,B-158,430,148);
ctx.fillStyle="#c8860a"; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText("GENERAL NOTES:",L+44,B-144);
ctx.strokeStyle="#000"; ctx.lineWidth=0.5;
ctx.beginPath();ctx.moveTo(L+36,B-140);ctx.lineTo(L+466,B-140);ctx.stroke();
ctx.fillStyle="#000"; ctx.font="8px Arial,sans-serif";
[
"1.  ALL WORK SHALL CONFORM TO: 2022 CPC, OSHA 29 CFR 1926, CBC 2022, AND ASHRAE 90.1.",
"2.  ALL PIPING SYMBOLS SHALL BE PER ASME Y32.2.3.",
"3.  HYDROSTATIC TEST: "+job.testPSI+" PSI FOR 4 HOURS, WITNESSED. INSPECTOR TO SIGN FORM P-1.",
"4.  INSULATE ALL HOT AND CHILLED PIPING PER TITLE 24 PART 6.",
"5.  SEISMIC BRACING PER SMACNA IEMP 2ND EDITION AT ALL PRESCRIBED INTERVALS.",
"6.  HANGER SCHEDULE: ANVIL/GRINNELL/HILTI — ENGINEER-STAMPED REQUIRED.",
"7.  COORDINATE ALL TRADES PRIOR TO ROUGH-IN. MAINTAIN MINIMUM CLEARANCES.",
"8.  VERIFY ALL DIMENSIONS IN FIELD PRIOR TO SHOP FABRICATION.",
"9.  HANGER SPACING: "+job.hs+"'-0\" O.C. MAX — ANVIL FIG.260 CLEVIS HANGER.",
"10. SUBMIT SPOOL DRAWINGS TO GC A MINIMUM OF THREE (3) WEEKS BEFORE INSTALLATION.",
].forEach((n,i)=>ctx.fillText(n,L+44,B-128+i*11));
const rvX=R-190,rvY=B-158;
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(rvX,rvY,178,90); ctx.strokeRect(rvX,rvY,178,90);
ctx.fillStyle="#000"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("REVISION RECORD",rvX+89,rvY+13);
ctx.lineWidth=0.5;
[[0,rvY+17,178,rvY+17],[24,rvY+17,24,rvY+90],[116,rvY+17,116,rvY+90]]
.forEach(([x1,y1,x2,y2])=>{ctx.beginPath();ctx.moveTo(rvX+x1,y1);ctx.lineTo(rvX+x2,y2);ctx.stroke();});
ctx.font="7px Arial,sans-serif"; ctx.textAlign="left"; ctx.fillStyle="#777";
ctx.fillText("REV",rvX+5,rvY+27); ctx.fillText("DATE",rvX+28,rvY+27); ctx.fillText("DESCRIPTION",rvX+120,rvY+27);
ctx.fillStyle="#000";
ctx.fillText("A",rvX+7,rvY+41); ctx.fillText(job.today,rvX+28,rvY+41); ctx.fillText("INITIAL ISSUE",rvX+120,rvY+41);
["B","C","D"].forEach((r,i)=>{
ctx.fillText(r,rvX+7,rvY+55+i*13);
ctx.fillStyle="#ccc"; ctx.fillText("______________",rvX+28,rvY+55+i*13); ctx.fillStyle="#000";
});
northArrow(ctx,R-56,T+56);
const lx=R-196,ly=T+96,lw=184;
const litems=[
{d:(x,y)=>{ctx.fillStyle="#000";ctx.fillRect(x,y-4,22,9);},l:"PIPE — "+sc.a+" SYSTEM"},
{d:(x,y)=>{ctx.strokeStyle="#000";ctx.lineWidth=LW.PHANTOM;ctx.setLineDash([12,3,3,3]);ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+22,y);ctx.stroke();ctx.setLineDash([]);},l:"CENTERLINE (CL)"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symGate(ctx,0,0,11,null);ctx.restore();},l:"GATE VALVE OS&Y"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symGlobe(ctx,0,0,11,null);ctx.restore();},l:"GLOBE VALVE"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symCheck(ctx,0,0,11,null);ctx.restore();},l:"CHECK VALVE — SWING"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symBall(ctx,0,0,11,null);ctx.restore();},l:"BALL VALVE"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symButterfly(ctx,0,0,11,null);ctx.restore();},l:"BUTTERFLY VALVE"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symStrainer(ctx,0,0,11,null);ctx.restore();},l:"Y-STRAINER"},
{d:(x,y)=>{symGauge(ctx,x+10,y,null);},l:"PRESSURE GAUGE (PG)"},
{d:(x,y)=>{symThermo(ctx,x+10,y,null);},l:"THERMOMETER (TI)"},
{d:(x,y)=>{symAV(ctx,x+10,y);},l:"AUTO AIR VENT (A/V)"},
{d:(x,y)=>{symDrain(ctx,x+10,y);},l:"DRAIN VALVE (D/V)"},
{d:(x,y)=>{ctx.strokeStyle="rgba(160,110,30,0.55)";ctx.lineWidth=5;ctx.setLineDash([6,4]);ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+22,y);ctx.stroke();ctx.setLineDash([]);},l:"INSULATION"},
{d:(x,y)=>{symFlange(ctx,x+11,y,5,1);},l:"FLANGED CONNECTION"},
];
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(lx,ly,lw,litems.length*14+30); ctx.strokeRect(lx,ly,lw,litems.length*14+30);
ctx.fillStyle="#000"; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText("LEGEND — ASME Y32.2.3",lx+6,ly+14);
ctx.lineWidth=0.5; ctx.beginPath();ctx.moveTo(lx,ly+18);ctx.lineTo(lx+lw,ly+18);ctx.stroke();
litems.forEach((it,i) => {
const iy=ly+31+i*14;
ctx.save();ctx.fillStyle="#000";ctx.strokeStyle="#000";ctx.lineWidth=1.2;ctx.font="8px Arial,sans-serif";
it.d(lx+4,iy); ctx.restore();
ctx.fillStyle="#111"; ctx.font="8px Arial,sans-serif"; ctx.textAlign="left"; ctx.fillText(it.l,lx+32,iy+3);
});
titleBlock(ctx,W,H,inp,job,"PLAN VIEW — SUPPLY & RETURN PIPING","1");
}
function renderIso(canvas, job, inp) {
const ctx = canvas.getContext("2d");
const W = canvas.width, H = canvas.height;
initCanvas(ctx,W,H);
const ft  = Math.max(parseFloat(inp.runLength)||100,10);
const sz  = parseFloat(inp.pipeSize)||2;
const pR  = Math.max(5,Math.min(11,sz*2.0));
const sc  = job.sc;
const isR = job.isR;
const c30 = Math.cos(Math.PI/6), s30 = Math.sin(Math.PI/6);
const L=50,R=W-50,T=60,B=H-120;
const nFl = job.nFl||3;
const {seg1,seg2,seg3} = job;
const rScl = 110;
const kpts = isR ? [
[0,0,0],[seg1,0,0],[seg1,0,seg2],[seg1,nFl,seg2],[seg1+seg3,nFl,seg2],
...[...Array(nFl+1)].flatMap((_,fl)=>[[0,fl,0],[(seg1+seg3)*0.94,fl,seg2*1.35]])
] : [[0,0,0],[ft,0,0]];
const raw1 = kpts.map(([wx,wy,wz])=>({sx:wx*c30-wz*c30,sy:-wy*rScl+wx*s30+wz*s30}));
const xs=raw1.map(p=>p.sx),ys=raw1.map(p=>p.sy);
const minX=Math.min(...xs),maxX=Math.max(...xs);
const minY=Math.min(...ys),maxY=Math.max(...ys);
const rawW=maxX-minX||1, rawH=maxY-minY||1;
const padL=160,padR=210,padT=90,padB=110;
const availW=(R-L)-padL-padR, availH=(B-T)-padT-padB;
const scl = Math.min(availW/rawW, availH/rawH, 9.0);
const cx=L+padL+availW/2, cy=T+padT+availH/2;
const ox=cx-(minX+maxX)/2*scl, oy=cy-(minY+maxY)/2*scl;
const iso=(wx,wy,wz)=>({
sx: ox+wx*scl*c30-wz*scl*c30,
sy: oy-wy*rScl+wx*scl*s30+wz*scl*s30
});
const pLine=(p1,p2,specLines)=>{
const dx=p2.sx-p1.sx,dy=p2.sy-p1.sy,len=Math.sqrt(dx*dx+dy*dy);
if(len<2)return;
ctx.strokeStyle="rgba(0,0,0,0.08)"; ctx.lineWidth=pR*2+8; ctx.lineCap="round";
ctx.beginPath();ctx.moveTo(p1.sx+3,p1.sy+4);ctx.lineTo(p2.sx+3,p2.sy+4);ctx.stroke();
ctx.strokeStyle="#000"; ctx.lineWidth=pR*2; ctx.lineCap="round";
ctx.beginPath();ctx.moveTo(p1.sx,p1.sy);ctx.lineTo(p2.sx,p2.sy);ctx.stroke();
ctx.strokeStyle="#000"; ctx.lineWidth=LW.PHANTOM; ctx.setLineDash([14,4,4,4]);
ctx.beginPath();ctx.moveTo(p1.sx,p1.sy);ctx.lineTo(p2.sx,p2.sy);ctx.stroke();
ctx.setLineDash([]);
if(len>50){
const bL=Math.min(32,len*0.15),mx=(p1.sx+p2.sx)/2,my=(p1.sy+p2.sy)/2;
const bu=dx/len,bv=dy/len,bny=-bv*pR,bnx=bu*pR;
ctx.fillStyle=sc.m;
ctx.beginPath();
ctx.moveTo(mx-bu*bL+bny,my-bv*bL+bnx);ctx.lineTo(mx+bu*bL+bny,my+bv*bL+bnx);
ctx.lineTo(mx+bu*bL-bny,my+bv*bL-bnx);ctx.lineTo(mx-bu*bL-bny,my-bv*bL-bnx);
ctx.closePath();ctx.fill();
ctx.fillStyle=sc.t; ctx.font=`bold ${Math.max(7,pR*0.85)}px Arial,sans-serif`;
ctx.textAlign="center"; ctx.fillText(sc.a,mx,my+3);
}
if(specLines){
const lx=(p1.sx+p2.sx)/2, ly=(p1.sy+p2.sy)/2-pR-68;
let mw=0;
ctx.font="8px Arial,sans-serif";
specLines.forEach(s=>{const w=ctx.measureText(s).width+16;if(w>mw)mw=w;});
const lh=specLines.length*13+10;
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(lx-mw/2,ly,mw,lh); ctx.strokeRect(lx-mw/2,ly,mw,lh);
ctx.fillStyle="#000"; ctx.font="8px Arial,sans-serif"; ctx.textAlign="left";
specLines.forEach((s,i)=>ctx.fillText(s,lx-mw/2+8,ly+12+i*13));
ctx.strokeStyle="#000"; ctx.lineWidth=0.8;
ctx.beginPath();ctx.moveTo(lx,ly+lh);ctx.lineTo(lx,(p1.sy+p2.sy)/2-pR-2);ctx.stroke();
ctx.fillStyle="#000"; ctx.beginPath();ctx.arc(lx,(p1.sy+p2.sy)/2-pR-2,2.5,0,Math.PI*2);ctx.fill();
}
};
const isoElbow=pt=>{
ctx.fillStyle="#000"; ctx.beginPath();ctx.arc(pt.sx,pt.sy,pR+4,0,Math.PI*2);ctx.fill();
ctx.strokeStyle="#c8860a"; ctx.lineWidth=2;
ctx.beginPath();ctx.arc(pt.sx,pt.sy,pR+7,0,Math.PI*2);ctx.stroke();
ctx.fillStyle="rgba(255,255,255,0.3)";
ctx.beginPath();ctx.arc(pt.sx-2,pt.sy-2,4,0,Math.PI*2);ctx.fill();
};
const isoGate=(pt,dx,dy,tag)=>{
const S=pR*2.2,nx=-dy*S,ny=dx*S;
ctx.fillStyle="#000"; ctx.strokeStyle="#000"; ctx.lineWidth=LW.MEDIUM;
ctx.beginPath();ctx.moveTo(pt.sx-dx*S,pt.sy-dy*S);ctx.lineTo(pt.sx-dx*S+nx,pt.sy-dy*S+ny);ctx.lineTo(pt.sx,pt.sy);ctx.closePath();ctx.fill();ctx.stroke();
ctx.beginPath();ctx.moveTo(pt.sx+dx*S,pt.sy+dy*S);ctx.lineTo(pt.sx+dx*S+nx,pt.sy+dy*S+ny);ctx.lineTo(pt.sx,pt.sy);ctx.closePath();ctx.fill();ctx.stroke();
ctx.lineWidth=1.5;
ctx.beginPath();ctx.moveTo(pt.sx,pt.sy);ctx.lineTo(pt.sx+nx*1.8,pt.sy+ny*1.8);ctx.stroke();
ctx.beginPath();ctx.arc(pt.sx+nx*1.8,pt.sy+ny*1.8,S*0.78,0,Math.PI*2);ctx.stroke();
ctx.lineWidth=1;
ctx.beginPath();ctx.moveTo(pt.sx+nx*1.8-S*0.78,pt.sy+ny*1.8);ctx.lineTo(pt.sx+nx*1.8+S*0.78,pt.sy+ny*1.8);ctx.stroke();
if(tag){
ctx.fillStyle="#000"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText(tag,pt.sx+nx*3.4,pt.sy+ny*3.4+3);
}
};
const isoStrain=(pt,tag)=>{
const S=pR*1.8;
ctx.fillStyle="#fff"; ctx.strokeStyle="#000"; ctx.lineWidth=LW.MEDIUM;
ctx.beginPath();ctx.moveTo(pt.sx-S,pt.sy);ctx.lineTo(pt.sx,pt.sy-S);ctx.lineTo(pt.sx+S,pt.sy);ctx.lineTo(pt.sx,pt.sy+S);ctx.closePath();ctx.fill();ctx.stroke();
ctx.lineWidth=0.7;
for(let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(pt.sx+i*S*0.22,pt.sy-S*0.32);ctx.lineTo(pt.sx+i*S*0.22,pt.sy+S*0.32);ctx.stroke();}
if(tag){ctx.fillStyle="#000";ctx.font="bold 8px Arial,sans-serif";ctx.textAlign="center";ctx.fillText(tag,pt.sx,pt.sy+S+14);}
};
const isoHanger=pt=>{
ctx.strokeStyle="#555"; ctx.lineWidth=1; ctx.setLineDash([3,2]);
ctx.beginPath();ctx.moveTo(pt.sx,pt.sy-pR-2);ctx.lineTo(pt.sx,pt.sy-pR-36);ctx.stroke();
ctx.setLineDash([]);
ctx.strokeStyle="#333"; ctx.lineWidth=2;
ctx.beginPath();ctx.moveTo(pt.sx-14,pt.sy-pR-36);ctx.lineTo(pt.sx+14,pt.sy-pR-36);ctx.stroke();
ctx.beginPath();ctx.moveTo(pt.sx-14,pt.sy-pR-36);ctx.lineTo(pt.sx-14,pt.sy-pR-23);ctx.stroke();
ctx.beginPath();ctx.moveTo(pt.sx+14,pt.sy-pR-36);ctx.lineTo(pt.sx+14,pt.sy-pR-23);ctx.stroke();
ctx.fillStyle="#333"; ctx.beginPath();ctx.arc(pt.sx,pt.sy-pR-36,3,0,Math.PI*2);ctx.fill();
};
const isoClamp=pt=>{
ctx.strokeStyle="#000"; ctx.lineWidth=3;
ctx.beginPath();ctx.moveTo(pt.sx-20,pt.sy-7);ctx.lineTo(pt.sx+20,pt.sy-7);ctx.stroke();
ctx.beginPath();ctx.moveTo(pt.sx-20,pt.sy+7);ctx.lineTo(pt.sx+20,pt.sy+7);ctx.stroke();
ctx.lineWidth=4;
ctx.beginPath();ctx.moveTo(pt.sx+20,pt.sy-16);ctx.lineTo(pt.sx+20,pt.sy+16);ctx.stroke();
ctx.strokeStyle="#999"; ctx.lineWidth=0.7;
for(let i=-12;i<=12;i+=4){ctx.beginPath();ctx.moveTo(pt.sx+20,pt.sy+i);ctx.lineTo(pt.sx+30,pt.sy+i-10);ctx.stroke();}
ctx.fillStyle="#000";
[pt.sx-10,pt.sx+10].forEach(bx=>{ctx.beginPath();ctx.arc(bx,pt.sy,3,0,Math.PI*2);ctx.fill();});
ctx.fillStyle="#333"; ctx.font="bold 7px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("RC",pt.sx,pt.sy+24);
};
const floorSlab=fl=>{
const fw=(seg1+seg3)*0.94, fd=seg2*1.35;
const pts=[iso(0,fl,0),iso(fw,fl,0),iso(fw,fl,fd),iso(0,fl,fd)];
ctx.fillStyle=fl%2===0?"rgba(145,165,205,0.2)":"rgba(125,145,185,0.14)";
ctx.beginPath();ctx.moveTo(pts[0].sx,pts[0].sy);pts.forEach(p=>ctx.lineTo(p.sx,p.sy));ctx.closePath();ctx.fill();
ctx.strokeStyle="rgba(30,45,90,0.6)"; ctx.lineWidth=2;
ctx.beginPath();ctx.moveTo(pts[0].sx,pts[0].sy);pts.forEach(p=>ctx.lineTo(p.sx,p.sy));ctx.closePath();ctx.stroke();
ctx.strokeStyle="rgba(50,70,120,0.16)"; ctx.lineWidth=0.6;
for(let t2=0;t2<=1;t2+=0.05){
const x1=pts[0].sx+(pts[1].sx-pts[0].sx)*t2,y1=pts[0].sy+(pts[1].sy-pts[0].sy)*t2;
ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x1-12,y1+14);ctx.stroke();
}
const lp=iso(-0.07,fl,0);
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(lp.sx-86,lp.sy-12,82,17);ctx.strokeRect(lp.sx-86,lp.sy-12,82,17);
ctx.fillStyle="#000"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("FL-"+(fl+1)+"  EL. +"+fl*14+"'-0\"",lp.sx-45,lp.sy+1);
ctx.fillStyle="#666"; ctx.font="7px Arial,sans-serif";
ctx.fillText("8\" CONC. SLAB",lp.sx-45,lp.sy+12);
};
const isoDim=(p1,p2,lbl)=>{
const dx=p2.sx-p1.sx,dy=p2.sy-p1.sy,l=Math.sqrt(dx*dx+dy*dy);
if(l<8)return;
const nx=-dy/l,ny=dx/l,off=30;
ctx.strokeStyle="#000"; ctx.lineWidth=LW.THIN;
ctx.beginPath();ctx.moveTo(p1.sx,p1.sy);ctx.lineTo(p1.sx+nx*off,p1.sy+ny*off);ctx.stroke();
ctx.beginPath();ctx.moveTo(p2.sx,p2.sy);ctx.lineTo(p2.sx+nx*off,p2.sy+ny*off);ctx.stroke();
ctx.beginPath();ctx.moveTo(p1.sx+nx*off,p1.sy+ny*off);ctx.lineTo(p2.sx+nx*off,p2.sy+ny*off);ctx.stroke();
const aL=9,aW=3;
[[p1,1],[p2,-1]].forEach(([p,d])=>{
ctx.fillStyle="#000"; ctx.beginPath();
ctx.moveTo(p.sx+nx*off,p.sy+ny*off);
ctx.lineTo(p.sx+nx*off+dx/l*d*aL-ny*aW,p.sy+ny*off+dy/l*d*aL+nx*aW);
ctx.lineTo(p.sx+nx*off+dx/l*d*aL+ny*aW,p.sy+ny*off+dy/l*d*aL-nx*aW);
ctx.closePath();ctx.fill();
});
const mx=(p1.sx+p2.sx)/2+nx*off,my=(p1.sy+p2.sy)/2+ny*off-7;
ctx.font="bold 8.5px Arial,sans-serif";
const tw=ctx.measureText(lbl).width+12;
ctx.fillStyle="#fff"; ctx.fillRect(mx-tw/2,my-11,tw,15);
ctx.fillStyle="#000"; ctx.textAlign="center"; ctx.fillText(lbl,mx,my);
};
if(isR) for(let fl=0;fl<=nFl;fl++) floorSlab(fl);
const s1s=iso(0,0,0), s1e=iso(seg1,0,0);
pLine(s1s,s1e,[inp.pipeSize+" "+inp.material,inp.joiningMethod+" — ["+sc.a+"]",sc.d]);
for(let f=job.hs;f<seg1;f+=job.hs) isoHanger(iso(f,0,0));
const isoGapMin=Math.max(110,(s1e.sx-s1s.sx)/5);
let lastIsoX=-9999;
[
[0.07,pt=>isoStrain(pt,"STR-1")],
[0.30,pt=>{const p2=iso(0.35*seg1,0,0);const ddx=p2.sx-pt.sx,ddy=p2.sy-pt.sy,ddl=Math.sqrt(ddx*ddx+ddy*ddy);isoGate(pt,ddl>0?ddx/ddl:1,ddl>0?ddy/ddl:0,"GV-1");}],
[0.60,pt=>{const p2=iso(0.65*seg1,0,0);const ddx=p2.sx-pt.sx,ddy=p2.sy-pt.sy,ddl=Math.sqrt(ddx*ddx+ddy*ddy);isoGate(pt,ddl>0?ddx/ddl:1,ddl>0?ddy/ddl:0,"GV-2");}],
[0.85,pt=>isoStrain(pt,"STR-2")],
].forEach(([f,fn])=>{
const pt=iso(f*seg1,0,0);
if(pt.sx-lastIsoX>=isoGapMin){fn(pt);lastIsoX=pt.sx;}
});
symAV(ctx,iso(seg1*0.93,0,0).sx,iso(seg1*0.93,0,0).sy-pR-9);
symDrain(ctx,iso(seg1*0.06,0,0).sx,iso(seg1*0.06,0,0).sy+pR+6);
if(isR){
isoElbow(s1e);
const s2e=iso(seg1,0,seg2);
pLine(s1e,s2e,null);
const dMid=iso(seg1,0,seg2*0.5);
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=0.9;
ctx.fillRect(dMid.sx+14,dMid.sy-10,130,14); ctx.strokeRect(dMid.sx+14,dMid.sy-10,130,14);
ctx.fillStyle="#000"; ctx.font="8px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText(inp.pipeSize+" OFFSET — ["+sc.a+"]",dMid.sx+18,dMid.sy+1);
isoElbow(s2e);
const s3e=iso(seg1,nFl,seg2);
pLine(s2e,s3e,null);
const rMid=iso(seg1,nFl*0.5,seg2);
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=0.9;
ctx.fillRect(rMid.sx+14,rMid.sy-10,160,14); ctx.strokeRect(rMid.sx+14,rMid.sy-10,160,14);
ctx.fillStyle="#000"; ctx.font="8px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText(inp.pipeSize+" RISER [VERT.] — "+sc.d,rMid.sx+18,rMid.sy+1);
for(let fli=1;fli<=nFl;fli++) isoClamp(iso(seg1,fli,seg2));
isoElbow(s3e);
const s4e=iso(seg1+seg3,nFl,seg2);
pLine(s3e,s4e,null);
for(let f2=job.hs;f2<seg3;f2+=job.hs) isoHanger(iso(seg1+f2,nFl,seg2));
const t1=iso(seg1+seg3*0.4,nFl,seg2),t1n=iso(seg1+seg3*0.45,nFl,seg2);
const t1dx=t1n.sx-t1.sx,t1dy=t1n.sy-t1.sy,t1dl=Math.sqrt(t1dx*t1dx+t1dy*t1dy);
isoGate(t1,t1dl>0?t1dx/t1dl:1,t1dl>0?t1dy/t1dl:0,"GV-3");
symAV(ctx,iso(seg1+seg3*0.87,nFl,seg2).sx,iso(seg1+seg3*0.87,nFl,seg2).sy-pR-9);
const dp=s4e;
ctx.fillStyle="#601a1a"; ctx.strokeStyle="#c0392b"; ctx.lineWidth=2;
ctx.beginPath();ctx.arc(dp.sx,dp.sy,pR+8,0,Math.PI*2);ctx.fill();ctx.stroke();
ctx.strokeStyle="#ff6b6b"; ctx.lineWidth=1;
ctx.beginPath();ctx.arc(dp.sx,dp.sy,pR+12,0,Math.PI*2);ctx.stroke();
ctx.fillStyle="#fab1a0"; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("DEST.",dp.sx,dp.sy+pR+25);
isoDim(iso(0,0,0),iso(seg1,0,0),Math.round(seg1)+"'-0\"");
const rv1=iso(seg1,0,seg2),rv2=iso(seg1,nFl,seg2);
ctx.strokeStyle="#000"; ctx.lineWidth=LW.THIN; ctx.setLineDash([3,3]);
ctx.beginPath();ctx.moveTo(rv1.sx+36,rv1.sy);ctx.lineTo(rv2.sx+36,rv2.sy);ctx.stroke();
ctx.setLineDash([]);
ctx.beginPath();ctx.moveTo(rv1.sx,rv1.sy);ctx.lineTo(rv1.sx+36,rv1.sy);ctx.stroke();
ctx.beginPath();ctx.moveTo(rv2.sx,rv2.sy);ctx.lineTo(rv2.sx+36,rv2.sy);ctx.stroke();
const rLbl=nFl+" FL — "+nFl*14+"'-0\" RISE";
ctx.font="bold 8.5px Arial,sans-serif";
const rtw=ctx.measureText(rLbl).width+14;
ctx.fillStyle="#fff"; ctx.fillRect(rv1.sx+38,(rv1.sy+rv2.sy)/2-11,rtw,15);
ctx.fillStyle="#000"; ctx.textAlign="left"; ctx.fillText(rLbl,rv1.sx+42,(rv1.sy+rv2.sy)/2);
isoDim(iso(seg1,nFl,seg2),iso(seg1+seg3,nFl,seg2),Math.round(seg3)+"'-0\"");
} else {
const ep=iso(ft,0,0);
ctx.fillStyle="#601a1a"; ctx.strokeStyle="#c0392b"; ctx.lineWidth=2;
ctx.beginPath();ctx.arc(ep.sx,ep.sy,pR+8,0,Math.PI*2);ctx.fill();ctx.stroke();
ctx.strokeStyle="#ff6b6b"; ctx.lineWidth=1;
ctx.beginPath();ctx.arc(ep.sx,ep.sy,pR+12,0,Math.PI*2);ctx.stroke();
ctx.fillStyle="#fab1a0"; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("DEST.",ep.sx,ep.sy+pR+25);
isoDim(iso(0,0,0),iso(ft,0,0),ft+"'-0\"  TOTAL RUN");
}
const sp=iso(0,0,0);
ctx.fillStyle="#1a3060"; ctx.strokeStyle="#2471a3"; ctx.lineWidth=2;
ctx.beginPath();ctx.arc(sp.sx,sp.sy,pR+8,0,Math.PI*2);ctx.fill();ctx.stroke();
ctx.strokeStyle="#74b9ff"; ctx.lineWidth=1;
ctx.beginPath();ctx.arc(sp.sx,sp.sy,pR+12,0,Math.PI*2);ctx.stroke();
ctx.fillStyle="#74b9ff"; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("SOURCE",sp.sx,sp.sy+pR+25);
const fa=iso(seg1*0.46,0,0),fa2=iso(seg1*0.52,0,0);
const fdx=fa2.sx-fa.sx,fdy=fa2.sy-fa.sy,fdl=Math.sqrt(fdx*fdx+fdy*fdy);
if(fdl>0){
ctx.fillStyle="rgba(255,255,255,0.9)";
ctx.beginPath();
ctx.moveTo(fa.sx+fdx/fdl*14,fa.sy+fdy/fdl*14);
ctx.lineTo(fa.sx-fdx/fdl*2+fdy/fdl*6,fa.sy-fdy/fdl*2-fdx/fdl*6);
ctx.lineTo(fa.sx,fa.sy);
ctx.lineTo(fa.sx-fdx/fdl*2-fdy/fdl*6,fa.sy-fdy/fdl*2+fdx/fdl*6);
ctx.closePath();ctx.fill();
ctx.strokeStyle="#000"; ctx.lineWidth=0.8; ctx.stroke();
}
const axO={sx:L+72,sy:B-56},axL=50;
[
[sc.a+" (E)",sc.m,{sx:axO.sx+axL*c30,sy:axO.sy-axL*s30}],
["Z (N)","#27ae60",{sx:axO.sx-axL*c30,sy:axO.sy-axL*s30}],
["Y (UP)","#2471a3",{sx:axO.sx,sy:axO.sy-axL}],
].forEach(([lbl,col,tp])=>{
ctx.strokeStyle=col; ctx.lineWidth=2.5;
ctx.beginPath();ctx.moveTo(axO.sx,axO.sy);ctx.lineTo(tp.sx,tp.sy);ctx.stroke();
const ddx=tp.sx-axO.sx,ddy=tp.sy-axO.sy,dl=Math.sqrt(ddx*ddx+ddy*ddy);
ctx.fillStyle=col;
ctx.beginPath();ctx.moveTo(tp.sx,tp.sy);
ctx.lineTo(tp.sx-ddx/dl*10+ddy/dl*3.5,tp.sy-ddy/dl*10-ddx/dl*3.5);
ctx.lineTo(tp.sx-ddx/dl*10-ddy/dl*3.5,tp.sy-ddy/dl*10+ddx/dl*3.5);
ctx.closePath();ctx.fill();
ctx.font="bold 8.5px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText(lbl,tp.sx+(tp.sx>axO.sx?18:tp.sx<axO.sx?-18:0),tp.sy+(tp.sy<axO.sy?-8:13));
});
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(L+36,B-90,438,78); ctx.strokeRect(L+36,B-90,438,78);
ctx.fillStyle="#c8860a"; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText("NOTES:",L+44,B-76);
ctx.lineWidth=0.5; ctx.beginPath();ctx.moveTo(L+36,B-72);ctx.lineTo(L+474,B-72);ctx.stroke();
ctx.fillStyle="#000"; ctx.font="8px Arial,sans-serif";
[
"1. ISOMETRIC IS DIAGRAMMATIC — NOT TO SCALE.",
"2. ALL SYMBOLS PER ASME Y32.2.3 — SINGLE-LINE PIPE CONVENTION.",
"3. VERIFY ALL DIMENSIONS AND ELEVATIONS IN FIELD BEFORE FABRICATION.",
"4. ALL PIPE SIZES NOMINAL UNLESS DIMENSIONED OTHERWISE.",
"5. WELD SYMBOLS PER AWS A2.4. SEE PLAN VIEW (SHEET 1) FOR COMPLETE NOTES.",
].forEach((n,i)=>ctx.fillText(n,L+44,B-58+i*11));
const rvX=R-190,rvY=B-90;
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(rvX,rvY,178,78); ctx.strokeRect(rvX,rvY,178,78);
ctx.fillStyle="#000"; ctx.font="bold 8px Arial,sans-serif"; ctx.textAlign="center";
ctx.fillText("REVISION RECORD",rvX+89,rvY+13);
ctx.lineWidth=0.5;
[[0,rvY+17,178,rvY+17],[24,rvY+17,24,rvY+78],[116,rvY+17,116,rvY+78]]
.forEach(([x1,y1,x2,y2])=>{ctx.beginPath();ctx.moveTo(rvX+x1,y1);ctx.lineTo(rvX+x2,y2);ctx.stroke();});
ctx.font="7px Arial,sans-serif"; ctx.textAlign="left"; ctx.fillStyle="#777";
ctx.fillText("REV",rvX+5,rvY+27); ctx.fillText("DATE",rvX+28,rvY+27); ctx.fillText("DESCRIPTION",rvX+120,rvY+27);
ctx.fillStyle="#000";
ctx.fillText("A",rvX+7,rvY+41); ctx.fillText(job.today,rvX+28,rvY+41); ctx.fillText("INITIAL ISSUE",rvX+120,rvY+41);
["B","C","D"].forEach((r,i)=>{
ctx.fillText(r,rvX+7,rvY+55+i*13);
ctx.fillStyle="#ccc"; ctx.fillText("______________",rvX+28,rvY+55+i*13); ctx.fillStyle="#000";
});
const lx=R-196,ly=T+54,lw=184;
const isoLgnd=[
{d:(x,y)=>{ctx.fillStyle="#000";ctx.fillRect(x,y-4,22,9);},l:"PIPE — "+sc.a+" SYS."},
{d:(x,y)=>{ctx.strokeStyle="#000";ctx.lineWidth=LW.PHANTOM;ctx.setLineDash([12,3,3,3]);ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+22,y);ctx.stroke();ctx.setLineDash([]);},l:"CENTERLINE (CL)"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symGate(ctx,0,0,11,null);ctx.restore();},l:"GATE VALVE OS&Y"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symCheck(ctx,0,0,11,null);ctx.restore();},l:"CHECK VALVE — SWING"},
{d:(x,y)=>{ctx.save();ctx.translate(x+11,y);ctx.scale(0.52,0.52);symStrainer(ctx,0,0,11,null);ctx.restore();},l:"Y-STRAINER"},
{d:(x,y)=>{ctx.fillStyle="#000";ctx.beginPath();ctx.arc(x+11,y,5,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#c8860a";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x+11,y,8,0,Math.PI*2);ctx.stroke();},l:"ELBOW — FIELD WELD"},
{d:(x,y)=>{symAV(ctx,x+11,y);},l:"AUTO AIR VENT (A/V)"},
{d:(x,y)=>{symDrain(ctx,x+11,y);},l:"DRAIN VALVE (D/V)"},
{d:(x,y)=>{ctx.strokeStyle="#444";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y-5);ctx.lineTo(x+22,y-5);ctx.stroke();ctx.beginPath();ctx.moveTo(x,y+5);ctx.lineTo(x+22,y+5);ctx.stroke();},l:"HANGER / SUPPORT"},
];
if(isR){
isoLgnd.push({d:(x,y)=>{ctx.strokeStyle="#000";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x,y-5);ctx.lineTo(x+22,y-5);ctx.stroke();ctx.beginPath();ctx.moveTo(x,y+5);ctx.lineTo(x+22,y+5);ctx.stroke();ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x+22,y-12);ctx.lineTo(x+22,y+12);ctx.stroke();},l:"RISER CLAMP"});
isoLgnd.push({d:(x,y)=>{ctx.fillStyle="rgba(145,165,205,0.5)";ctx.strokeStyle="#000";ctx.lineWidth=1;ctx.fillRect(x,y-6,22,12);ctx.strokeRect(x,y-6,22,12);},l:"FLOOR SLAB"});
}
isoLgnd.push({d:(x,y)=>{ctx.fillStyle="#1a3060";ctx.strokeStyle="#2471a3";ctx.lineWidth=1;ctx.beginPath();ctx.arc(x+11,y,7,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.strokeStyle="#74b9ff";ctx.lineWidth=0.8;ctx.beginPath();ctx.arc(x+11,y,10,0,Math.PI*2);ctx.stroke();},l:"SOURCE / DEST."});
const lh=isoLgnd.length*14+30;
ctx.fillStyle="#fffff8"; ctx.strokeStyle="#000"; ctx.lineWidth=1;
ctx.fillRect(lx,ly,lw,lh); ctx.strokeRect(lx,ly,lw,lh);
ctx.fillStyle="#000"; ctx.font="bold 9px Arial,sans-serif"; ctx.textAlign="left";
ctx.fillText("SYMBOL LEGEND — ASME Y32.2.3",lx+6,ly+14);
ctx.lineWidth=0.5; ctx.beginPath();ctx.moveTo(lx,ly+18);ctx.lineTo(lx+lw,ly+18);ctx.stroke();
isoLgnd.forEach((it,i)=>{
const iy=ly+31+i*14;
ctx.save();ctx.fillStyle="#000";ctx.strokeStyle="#000";ctx.lineWidth=1.2;ctx.font="8px Arial,sans-serif";
it.d(lx+4,iy);ctx.restore();
ctx.fillStyle="#111"; ctx.font="8px Arial,sans-serif"; ctx.textAlign="left"; ctx.fillText(it.l,lx+30,iy+3);
});
northArrow(ctx,R-56,T+56);
titleBlock(ctx,W,H,inp,job,isR?"ISOMETRIC VIEW — RISER ELEVATION":"ISOMETRIC VIEW — HORIZONTAL RUN","2");
}
const CAT_COLOR={PIPE:"#c8860a",FITTINGS:"#3b82f6",VALVES:"#ef4444",INST:"#22c55e",SUPPORTS:"#a855f7",INSUL:"#eab308",MISC:"#64748b"};

function PipeAI(){
  const [inp,setInp]=useState({jobDesc:"",pipeSize:'2"',material:"Schedule 80 Steel",systemType:"Domestic Hot Water",runLength:"180",buildingType:"Commercial Office",joiningMethod:"Threaded",special:""});
  const [job,setJob]=useState(null);
  const [tab,setTab]=useState("plan");
  const [busy,setBusy]=useState(false);
  const [fs,setFs]=useState(false);
  const [sideOpen,setSideOpen]=useState(true);
  const planRef=useRef(null);
  const isoRef=useRef(null);
  const set=k=>e=>setInp(p=>({...p,[k]:e.target.value}));

  useEffect(()=>{
    if(!job)return;
    const t=setTimeout(()=>{
      if(tab==="plan"&&planRef.current)renderPlan(planRef.current,job,inp);
      if(tab==="isometric"&&isoRef.current)renderIso(isoRef.current,job,inp);
    },30);
    return ()=>clearTimeout(t);
  },[tab,job]);

  function generate(){
    setBusy(true);
    setTimeout(()=>{
      const j=buildJob(inp);setJob(j);setTab("plan");
      setTimeout(()=>{if(planRef.current)renderPlan(planRef.current,j,inp);setBusy(false);},60);
    },50);
  }

  function savePNG(){
    const ref=tab==="plan"?planRef.current:isoRef.current;if(!ref||!job)return;
    const a=document.createElement("a");
    a.download=job.dwgNo+"_"+(tab==="plan"?"Plan":"ISO")+".png";
    a.href=ref.toDataURL("image/png");a.click();
  }

  const SZ=['1/2"','3/4"','1"','1-1/4"','1-1/2"','2"','2-1/2"','3"','4"','6"','8"'];
  const MT=["Type L Copper","Type K Copper","Sch 40 Steel","Schedule 80 Steel","304 Stainless","CPVC","PEX","Victaulic Grooved"];
  const SY=["Domestic Hot Water","Domestic Cold Water","Steam","Condensate Return","Chilled Water Supply","Chilled Water Return","Hydronic Heating","Process Piping","Gas (Med Pressure)","Fire Protection"];
  const BT=["Commercial Office","Hospital / Healthcare","Hotel","Industrial","High-Rise Residential","Lab / R&D","Data Center","School"];
  const JN=["Threaded","Welded (Butt)","Welded (Socket)","Grooved / Victaulic","Soldered","Pressed Fitting","Flanged"];
  const TABS=[{id:"plan",icon:"⊡",label:"Plan View"},{id:"isometric",icon:"◈",label:"Isometric"},{id:"details",icon:"≡",label:"Field Notes"},{id:"materials",icon:"⊞",label:"Takeoff"}];
  const IS={width:"100%",background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"7px",color:"#e2e8f0",padding:"8px 11px",fontSize:"12px",fontFamily:"inherit",outline:"none"};
  const LS={display:"block",fontSize:"10px",fontWeight:"600",letterSpacing:"0.12em",color:"rgba(148,163,184,0.65)",textTransform:"uppercase",marginBottom:"5px"};

  return (
    <div style={{background:"#0a0d14",color:"#e2e8f0",height:"100vh",display:"flex",flexDirection:"column",overflow:"hidden",fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"}}>
      <style>{`*{box-sizing:border-box}select option{background:#1a2035}::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:rgba(200,134,10,0.3);border-radius:4px}input:focus,select:focus,textarea:focus{border-color:rgba(200,134,10,0.6)!important;box-shadow:0 0 0 3px rgba(200,134,10,0.08)!important;outline:none!important}@keyframes spin{to{transform:rotate(360deg)}}@keyframes fadeUp{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}.fu{animation:fadeUp 0.2s ease both}.fs-overlay{position:fixed;inset:0;background:#000;z-index:1000;display:flex;flex-direction:column}.fs-overlay canvas{width:100%!important;height:auto!important;max-height:100vh;object-fit:contain}`}</style>

      {fs&&(tab==="plan"||tab==="isometric")&&(
        <div className="fs-overlay">
          <div style={{height:"44px",background:"#050811",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 18px",flexShrink:"0",borderBottom:"1px solid rgba(200,134,10,0.2)"}}>
            <div style={{display:"flex",alignItems:"center",gap:"10px"}}>
              <div style={{width:"28px",height:"28px",borderRadius:"6px",background:"linear-gradient(135deg,#c8860a,#f0a832)",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"800",fontSize:"12px",color:"#000"}}>38</div>
              <span style={{fontWeight:"700",fontSize:"13px",letterSpacing:"0.1em",color:"#f1f5f9"}}>PIPE AI</span>
              {job&&<span style={{fontSize:"10px",color:"rgba(200,134,10,0.7)",marginLeft:"4px"}}>{job.dwgNo} — {tab==="plan"?"PLAN VIEW":"ISOMETRIC"}</span>}
            </div>
            <div style={{display:"flex",gap:"8px"}}>
              <button onClick={savePNG} style={{padding:"5px 14px",background:"rgba(200,134,10,0.15)",color:"#f0a832",border:"1px solid rgba(200,134,10,0.3)",borderRadius:"6px",cursor:"pointer",fontSize:"11px",fontWeight:"600"}}>↓ Save PNG</button>
              <button onClick={()=>setFs(false)} style={{padding:"5px 14px",background:"rgba(255,255,255,0.08)",color:"#e2e8f0",border:"1px solid rgba(255,255,255,0.12)",borderRadius:"6px",cursor:"pointer",fontSize:"11px",fontWeight:"600"}}>✕ Close</button>
            </div>
          </div>
          <div style={{flex:"1",overflow:"auto",background:"#111",display:"flex",alignItems:"center",justifyContent:"center"}}>
            {tab==="plan"&&<canvas ref={planRef} width={1500} height={960} style={{width:"100%",height:"auto",display:"block"}}/>}
            {tab==="isometric"&&<canvas ref={isoRef} width={1500} height={1100} style={{width:"100%",height:"auto",display:"block"}}/>}
          </div>
        </div>
      )}

      <header style={{height:"54px",background:"#050811",borderBottom:"1px solid rgba(255,255,255,0.07)",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 22px",flexShrink:"0"}}>
        <div style={{display:"flex",alignItems:"center",gap:"12px"}}>
          <div style={{width:"34px",height:"34px",borderRadius:"8px",background:"linear-gradient(135deg,#c8860a,#f0a832)",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"800",fontSize:"14px",color:"#000",boxShadow:"0 2px 10px rgba(200,134,10,0.4)"}}>38</div>
          <div>
            <div style={{fontWeight:"700",fontSize:"15px",letterSpacing:"0.08em",lineHeight:"1"}}>PIPE AI</div>
            <div style={{fontSize:"9px",color:"rgba(200,134,10,0.75)",letterSpacing:"0.22em",marginTop:"2px"}}>UA LOCAL 38 - SAN FRANCISCO</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:"10px"}}>
          {job&&<div style={{display:"flex",gap:"6px"}}>
            {[{l:"DWG",v:job.dwgNo},{l:"TEST",v:job.testPSI+" PSI"},{l:"LABOR",v:job.laborHours+" HRS"}].map(s=>(
              <div key={s.l} style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:"6px",padding:"4px 10px",display:"flex",gap:"6px",alignItems:"center"}}>
                <span style={{fontSize:"9px",color:"rgba(148,163,184,0.5)",letterSpacing:"0.15em"}}>{s.l}</span>
                <span style={{fontSize:"10px",fontWeight:"600"}}>{s.v}</span>
              </div>
            ))}
          </div>}
          <div style={{background:"rgba(200,134,10,0.1)",border:"1px solid rgba(200,134,10,0.28)",borderRadius:"6px",padding:"4px 12px"}}>
            <span style={{fontSize:"10px",color:"#f0a832",fontWeight:"700"}}>v9.0 </span>
            <span style={{fontSize:"9px",color:"rgba(200,134,10,0.45)"}}>ME STANDARD</span>
          </div>
        </div>
      </header>

      <div style={{flex:"1",display:"flex",overflow:"hidden"}}>
        <aside style={{width:sideOpen?"268px":"0px",flexShrink:"0",background:"#0d1117",borderRight:"1px solid rgba(255,255,255,0.06)",display:"flex",flexDirection:"column",overflow:"hidden",transition:"width 0.2s ease"}}>
          <div style={{padding:"14px 18px 10px",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
            <div style={{fontSize:"10px",fontWeight:"700",letterSpacing:"0.22em",color:"rgba(148,163,184,0.45)",textTransform:"uppercase"}}>Job Parameters</div>
          </div>
          <div style={{flex:"1",overflowY:"auto",padding:"14px 18px"}}>
            <div style={{marginBottom:"14px"}}>
              <label style={LS}>Job Description</label>
              <textarea rows={3} value={inp.jobDesc} onChange={set("jobDesc")} placeholder={"2\" DHW riser basement to 4th floor\nAdd 'riser' for vertical isometric"} style={{...IS,resize:"none",lineHeight:"1.6"}}/>
              <div style={{fontSize:"9px",color:"rgba(148,163,184,0.3)",marginTop:"4px"}}>Include 'riser' for vertical ISO</div>
            </div>
            {[
              [["Pipe Size",SZ,"pipeSize"],["Material",MT,"material"]],
              [["System Type",SY,"systemType"],["Run Length (LF)",null,"runLength"]],
              [["Building Type",BT,"buildingType"],["Joining Method",JN,"joiningMethod"]],
            ].map((row,ri)=>(
              <div key={ri} style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"8px",marginBottom:"12px"}}>
                {row.map(([label,opts,k])=>(
                  <div key={k}>
                    <label style={LS}>{label}</label>
                    {opts
                      ? <select value={inp[k]} onChange={set(k)} style={{...IS,cursor:"pointer"}}>{opts.map(o=><option key={o}>{o}</option>)}</select>
                      : <input type="number" value={inp[k]} onChange={set(k)} min={10} max={5000} style={IS}/>
                    }
                  </div>
                ))}
              </div>
            ))}
            <div style={{marginBottom:"14px"}}>
              <label style={LS}>Special Conditions</label>
              <input type="text" value={inp.special} onChange={set("special")} placeholder="OSHPD, seismic, LEED, confined..." style={IS}/>
            </div>
            <div style={{padding:"8px 12px",borderRadius:"8px",background:gs(inp.systemType).m+"18",border:"1px solid "+gs(inp.systemType).m+"30",display:"flex",alignItems:"center",gap:"8px"}}>
              <div style={{width:"8px",height:"8px",borderRadius:"50%",background:gs(inp.systemType).m,flexShrink:"0"}}/>
              <span style={{fontSize:"10px",color:gs(inp.systemType).m,fontWeight:"700",letterSpacing:"0.15em"}}>{gs(inp.systemType).a}</span>
              <span style={{fontSize:"9px",color:"rgba(148,163,184,0.4)"}}>{gs(inp.systemType).d}</span>
            </div>
          </div>
          <div style={{padding:"14px 18px",borderTop:"1px solid rgba(255,255,255,0.05)"}}>
            <button onClick={generate} disabled={busy} style={{width:"100%",padding:"12px 0",background:busy?"rgba(200,134,10,0.25)":"linear-gradient(135deg,#c8860a,#d4920e)",color:busy?"rgba(255,255,255,0.3)":"#000",border:"none",borderRadius:"9px",fontWeight:"700",fontSize:"13px",letterSpacing:"0.06em",cursor:busy?"not-allowed":"pointer",transition:"all 0.18s",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px"}}>
              {busy
                ? <><span style={{width:"13px",height:"13px",border:"2px solid rgba(255,255,255,0.2)",borderTopColor:"rgba(255,255,255,0.7)",borderRadius:"50%",animation:"spin 0.75s linear infinite",display:"inline-block"}}/> Generating...</>
                : "Generate Drawings"
              }
            </button>
            <div style={{marginTop:"8px",textAlign:"center",fontSize:"9px",color:"rgba(148,163,184,0.25)",letterSpacing:"0.08em"}}>ASME Y32.2.3 - PLAN + ISO - TITLE BLOCK</div>
          </div>
        </aside>

        <main style={{flex:"1",display:"flex",flexDirection:"column",overflow:"hidden"}}>
          <div style={{height:"46px",background:"rgba(5,8,17,0.98)",borderBottom:"1px solid rgba(255,255,255,0.06)",display:"flex",alignItems:"center",padding:"0 16px",gap:"3px",flexShrink:"0"}}>
            <button onClick={()=>setSideOpen(o=>!o)} style={{padding:"5px 8px",background:"transparent",color:"rgba(148,163,184,0.4)",border:"none",borderRadius:"7px",cursor:"pointer",fontSize:"16px",lineHeight:"1",marginRight:"4px"}} title="Toggle sidebar">&#9776;</button>
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)} style={{padding:"5px 14px",background:tab===t.id?"#c8860a":"transparent",color:tab===t.id?"#000":"rgba(148,163,184,0.55)",border:"none",borderRadius:"7px",cursor:"pointer",fontSize:"12px",fontWeight:tab===t.id?700:500,transition:"all 0.15s",display:"flex",alignItems:"center",gap:"5px"}}>
                <span style={{fontSize:"11px"}}>{t.icon}</span>{t.label}
              </button>
            ))}
            <div style={{marginLeft:"auto",display:"flex",gap:"6px"}}>
              {job&&(tab==="plan"||tab==="isometric")&&(
                <button onClick={()=>setFs(true)} style={{padding:"5px 13px",background:"rgba(200,134,10,0.15)",color:"#f0a832",border:"1px solid rgba(200,134,10,0.3)",borderRadius:"7px",cursor:"pointer",fontSize:"11px",fontWeight:"700",display:"flex",alignItems:"center",gap:"5px"}}>
                  <span>&#x26F6;</span> Full Screen
                </button>
              )}
              {job&&(tab==="plan"||tab==="isometric")&&(
                <button onClick={savePNG} style={{padding:"5px 13px",background:"transparent",color:"rgba(200,134,10,0.75)",border:"1px solid rgba(200,134,10,0.2)",borderRadius:"7px",cursor:"pointer",fontSize:"11px",fontWeight:"600",display:"flex",alignItems:"center",gap:"4px"}}>
                  <span>&#8595;</span> Save PNG
                </button>
              )}
            </div>
          </div>

          <div style={{flex:"1",overflow:"auto",background:tab==="plan"||tab==="isometric"?"#111418":"#080b12"}}>
            {!job&&(
              <div style={{height:"100%",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:"16px"}}>
                <svg width="70" height="70" viewBox="0 0 70 70" style={{opacity:"0.1"}}><polygon points="35,3 65,19 65,51 35,67 5,51 5,19" fill="none" stroke="#c8860a" strokeWidth="2"/></svg>
                <div style={{textAlign:"center"}}>
                  <div style={{fontSize:"13px",fontWeight:"600",color:"rgba(148,163,184,0.18)",letterSpacing:"0.15em",textTransform:"uppercase"}}>Ready to Generate</div>
                  <div style={{fontSize:"11px",color:"rgba(148,163,184,0.12)",marginTop:"5px"}}>Enter job details and click Generate Drawings</div>
                </div>
                <div style={{display:"flex",gap:"6px",flexWrap:"wrap",justifyContent:"center",maxWidth:"460px"}}>
                  {["ASME Y32.2.3 Plan View","Isometric Drawing","Material Takeoff","Labor Estimate","Code Compliance","Prefab Strategy"].map(f=>(
                    <div key={f} style={{padding:"4px 11px",background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:"20px",fontSize:"10px",color:"rgba(148,163,184,0.25)"}}>{f}</div>
                  ))}
                </div>
              </div>
            )}
            {job&&tab==="plan"&&<div className="fu"><canvas ref={planRef} width={1500} height={960} style={{width:"100%",height:"auto",display:"block"}}/></div>}
            {job&&tab==="isometric"&&<div className="fu"><canvas ref={isoRef} width={1500} height={1100} style={{width:"100%",height:"auto",display:"block"}}/></div>}
            {job&&tab==="details"&&(
              <div className="fu" style={{padding:"30px 34px",maxWidth:"880px"}}>
                {[{label:"Routing Strategy",key:"routing",icon:">"},{label:"Code & Compliance",key:"compliance",icon:"#"},{label:"Labor Breakdown",key:"laborNotes",icon:"~"},{label:"Prefab Strategy",key:"prefab",icon:"+"}].map(item=>(
                  <div key={item.key} style={{marginBottom:"28px",paddingBottom:"28px",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
                    <div style={{display:"flex",alignItems:"center",gap:"10px",marginBottom:"12px"}}>
                      <div style={{width:"26px",height:"26px",borderRadius:"7px",background:"rgba(200,134,10,0.1)",border:"1px solid rgba(200,134,10,0.18)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"14px",color:"#c8860a",fontWeight:"bold"}}>{item.icon}</div>
                      <div style={{fontSize:"10px",fontWeight:"700",letterSpacing:"0.15em",color:"rgba(148,163,184,0.6)",textTransform:"uppercase"}}>{item.label}</div>
                    </div>
                    <div style={{fontSize:"13px",lineHeight:"1.9",color:"#94a3b8",whiteSpace:"pre-line"}}>{job[item.key]}</div>
                  </div>
                ))}
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"12px"}}>
                  {[{label:"Estimated Labor Hours",value:job.laborHours,unit:"HRS",color:"#c8860a"},{label:"Hydrostatic Test Pressure",value:String(job.testPSI),unit:"PSI",color:"#3b82f6"}].map(card=>(
                    <div key={card.label} style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:"10px",padding:"18px 20px"}}>
                      <div style={{fontSize:"9px",fontWeight:"600",letterSpacing:"0.18em",color:"rgba(148,163,184,0.45)",textTransform:"uppercase",marginBottom:"10px"}}>{card.label}</div>
                      <div style={{display:"flex",alignItems:"baseline",gap:"6px"}}>
                        <span style={{fontSize:"34px",fontWeight:"800",color:card.color,lineHeight:"1"}}>{card.value}</span>
                        <span style={{fontSize:"12px",color:"rgba(148,163,184,0.45)"}}>{card.unit}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {job&&tab==="materials"&&(
              <div className="fu" style={{padding:"26px 30px",maxWidth:"980px"}}>
                <div style={{display:"flex",gap:"7px",flexWrap:"wrap",marginBottom:"18px"}}>
                  {Object.entries(job.mats.filter(m=>m.q>0).reduce((acc,m)=>{acc[m.c]=(acc[m.c]||0)+1;return acc;},{})).map(([cat,count])=>(
                    <div key={cat} style={{display:"flex",alignItems:"center",gap:"5px",padding:"4px 11px",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:"20px"}}>
                      <div style={{width:"6px",height:"6px",borderRadius:"50%",background:CAT_COLOR[cat]||"#64748b"}}/>
                      <span style={{fontSize:"9px",fontWeight:"700",color:CAT_COLOR[cat]||"#94a3b8",letterSpacing:"0.1em"}}>{cat}</span>
                      <span style={{fontSize:"9px",color:"rgba(148,163,184,0.4)"}}>{count}</span>
                    </div>
                  ))}
                </div>
                <div style={{borderRadius:"10px",overflow:"hidden",border:"1px solid rgba(255,255,255,0.07)"}}>
                  <table style={{width:"100%",borderCollapse:"collapse",fontSize:"12px"}}>
                    <thead>
                      <tr style={{background:"rgba(255,255,255,0.04)"}}>
                        {["#","Cat","Description","Qty","Unit"].map((h,hi)=>(
                          <th key={h} style={{textAlign:hi>=3?"right":"left",color:"rgba(148,163,184,0.45)",fontSize:"9px",fontWeight:"700",letterSpacing:"0.15em",padding:"10px 13px",borderBottom:"1px solid rgba(255,255,255,0.07)",textTransform:"uppercase"}}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {job.mats.filter(m=>m.q>0).map((m,i)=>(
                        <tr key={i} style={{background:i%2===0?"transparent":"rgba(255,255,255,0.015)",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                          <td style={{padding:"9px 13px",color:"rgba(148,163,184,0.28)",fontSize:"9px",fontFamily:"monospace"}}>{String(i+1).padStart(2,"0")}</td>
                          <td style={{padding:"9px 13px"}}>
                            <span style={{display:"inline-flex",alignItems:"center",gap:"5px",padding:"2px 8px",background:(CAT_COLOR[m.c]||"#444")+"18",border:"1px solid "+(CAT_COLOR[m.c]||"#444")+"30",borderRadius:"5px"}}>
                              <span style={{width:"5px",height:"5px",borderRadius:"50%",background:CAT_COLOR[m.c]||"#64748b"}}/>
                              <span style={{fontSize:"9px",fontWeight:"700",color:CAT_COLOR[m.c]||"#94a3b8",letterSpacing:"0.08em"}}>{m.c}</span>
                            </span>
                          </td>
                          <td style={{padding:"9px 13px",color:"#cbd5e1"}}>{m.i}</td>
                          <td style={{padding:"9px 13px",textAlign:"right",color:"#f0a832",fontWeight:"700",fontSize:"14px",fontFamily:"monospace"}}>{m.q}</td>
                          <td style={{padding:"9px 13px",textAlign:"right",color:"rgba(148,163,184,0.45)",fontSize:"11px"}}>{m.u}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div style={{marginTop:"12px",padding:"11px 15px",background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.05)",borderRadius:"8px",fontSize:"10px",color:"rgba(148,163,184,0.3)",lineHeight:"1.7"}}>
                  Quantities include 5% waste factor. Verify against stamped drawings before procurement. UA Local 38 signatory contractor sourced. ASME B31.9.
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
export default PipeAI;
