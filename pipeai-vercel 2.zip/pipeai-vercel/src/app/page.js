"use client";
import PipeAI from "./PipeAI";

export default function Page() {
  return <PipeAI />;
}
